# Bluezone Trading Network — Mobile Interface Design

## Product Direction

Bluezone Trading Network is a **paper-trading workspace**, not a brokerage or live execution product. The attached source establishes a phone-first experience with a $10,000 paper account, a six-instrument watchlist, clear positive and negative market changes, and an explicit “Active • Simulation” state. The native continuation will preserve that intention while expanding the single static screen into a coherent iOS- and Android-ready training workspace.

The interface is designed for portrait use and frequent, one-handed checks. It keeps the account state and high-priority decisions visible on the dashboard; secondary detail, trade controls, and history are reached through familiar tab navigation and clear modal sheets. Every financial action is labelled **simulated**, and neither UI copy nor state will imply access to live prices, deposits, withdrawals, broker connectivity, or live order execution.

## Truthful Capability Boundary

| Capability | Current product state | Mobile behaviour |
|---|---|---|
| Paper account, starting balance, and positions | Internal and tested locally | Enable deposits only as a resettable local simulation and show the current virtual equity. |
| Sample watchlist prices and daily changes | Internal static training data | Render them as *sample market data*, show the timestamp/source status as unavailable, and avoid “live” claims. |
| Simulated buy/sell ticket | Internal local workflow | Create, validate, and persist virtual orders/positions on-device. |
| Live market data | Internal public-provider integration | Refresh server-side public quotes and show public, partial, unavailable, or bundled states without promising exchange-grade delivery. |
| Supabase synchronization mentioned in source | Client configuration verified; schema/function deployment pending | Keep local persistence as the default and activate cloud records only after the supplied schema and Edge Functions are deployed and verified. |
| Broker or exchange order routing | Legal/provider review pending | Do not expose deposits, withdrawals, broker accounts, leverage, or live order execution. |

## Screen List

| Screen | Primary content and functionality |
|---|---|
| Dashboard | Brand label, paper-account balance, simulated P&L, account state, market-data status, compact watchlist, and a prominent simulated-trade entry point. |
| Watchlist | Searchable, vertically scrolling list of the source instruments—XAUUSD, EURUSD, GBPUSD, USDJPY, BTCUSD, and US30—with price, change, and saved state. |
| Instrument Detail | Instrument identity, current sample price, session change, simulated position summary, recent price context, and a “Simulated trade” call to action. |
| Trade Ticket | Buy/sell selector, quantity input, estimated notional, validation, and a truthful confirmation for paper orders only. |
| Portfolio | Virtual equity, cash, total unrealized P&L, open positions, exposure summary, and an explicit reset option. |
| Activity | Local record of simulated orders, position changes, and reset events. |
| Settings | Training-data disclosure, paper-account reset control, and future-data connection status. |
| Strategies | Educational descriptions of the eight supplied trading methodologies, with no automated recommendation or execution. |
| Sessions | Market-session reference and user-selected practice context for Asia, London, and New York. |
| Education | Searchable learning modules drawn from the supplied Trading 101, Risk Management, and Trading Styles material. |
| Broker status | Provider-pending MT5/broker connection status, explicitly excluding credentials, account linkage, or order routing. |
| Profile | Local account summary plus opt-in Supabase configuration and cloud-readiness status. |

## Requirements-Aligned Navigation

The bottom navigation will follow the supplied seven-workspace model: **Markets**, **Chart**, **Sessions**, **AutoTrade**, **Brokers**, **More**, and **Profile**. The Chart route is a paper-trading analysis workspace and will use the selected market context. AutoTrade is a paper-only consensus education area; Brokers is a directory and provider-readiness screen, not a credential or execution form. More is the entry point for strategies, education, support, risk content, and integration status.

| Workspace | Mobile purpose | Safety and availability state |
|---|---|---|
| Markets | Filterable forex, metals, crypto, indices, and Deriv catalog with current public quotes where verified. | Every row carries public, training, or provider-pending state. |
| Chart | Selected instrument detail, timeframe context, chart display, strategy reference, and simulated trade entry. | Paper order flow only. |
| Sessions | Sydney, Tokyo, London, and New York UTC reference cards, overlap context, and practice preference selection. | Informational session guide; no performance claims. |
| AutoTrade | Deterministic consensus-learning cards, threshold control, paper-position summary, and journal access. | No broker action, no signal guarantee. |
| Brokers | Research directory and connection-readiness status. | External links only; no login, password, account linking, deposit, or execution controls. |
| More | Strategy library, education, public data status, risk reminder, support, and developer credit. | Educational and support content. |
| Profile | Supabase sign-in state, cloud-readiness state, paper account, and support. | No MT5 credential collection. |

## Developer Credit and Support

The support and credit surface will identify **Tseliso Sefale** as the developer/owner and show **Smartvibeslesotho@gmail.com**. Where device support is available, the app will open a pre-filled WhatsApp support link for **+266 6264 9248**; otherwise it will display the contact details without claiming that WhatsApp opened.

## Key User Flows

| User goal | Mobile flow |
|---|---|
| Review the account | Dashboard → paper account card → Portfolio. |
| Monitor an instrument | Dashboard or Watchlist → instrument row → Instrument Detail. |
| Place a practice trade | Instrument Detail → Simulated trade → Trade Ticket → validation → confirmation → Portfolio and Activity update. |
| Review training history | Activity tab → transaction row → relevant instrument context. |
| Restart the simulation | Settings → Reset paper account → confirm in a native-style alert → Dashboard state returns to the starting model. |
| Explore a learning module | More/Explore → Strategies, Sessions, or Education → educational detail → return to workspace. |
| Check integration readiness | Profile → Cloud and broker status → see configured versus provider-pending state without a false connection confirmation. |

## Layout and Interaction Principles

The dashboard opens with a small BLUEZONE TRADING NETWORK label and an expressive but legible “Markets” title, preserving the source hierarchy. The paper-account card uses Navy as the visual anchor with a teal simulation-status dot. The watchlist appears as high-contrast cards with symbol and instrument name aligned left; price and percentage movement align right. The negative change treatment always includes a minus sign and supporting color, while positive movement always includes a plus sign and supporting color.

The primary simulated-trade action is positioned in the lower portion of instrument screens or in the bottom sheet, avoiding unreachable header controls. Press feedback and light haptics support state changes, while confirmations explain the consequence before the simulated transaction changes virtual balances. No tap target will be decorative or inert.

## Brand Palette

| Token | Color | Intended use |
|---|---|---|
| Bluezone Navy | `#0B1220` | Account card, headings, and high-confidence anchors. |
| Bluezone Blue | `#2563EB` | Brand label, primary actions, active tab, and links. |
| Simulation Teal | `#0F9B8E` | Simulation status, positive changes, and completed local actions. |
| Mist | `#F8FAFC` | Light canvas background carried from the source project. |
| Surface | `#FFFFFF` | Watchlist cards, sheets, and forms. |
| Slate | `#64748B` | Instrument metadata and supporting copy. |
| Loss Red | `#E5484D` | Negative movements and destructive reset emphasis. |
| Border | `#E6EBF1` | Low-emphasis dividers and card boundaries. |

## Domain Model

| Entity | Core fields | Ownership and lifecycle |
|---|---|---|
| Instrument | symbol, name, sample price, change percentage, quote status | Bundled training data; read-only until an authorized data provider is configured. |
| Paper account | starting balance, cash, equity, realized P&L, reset date | Stored locally for the device user; resettable. |
| Simulated order | id, instrument, side, quantity, price, timestamp, status | Created locally after input validation; completed immediately as a simulation. |
| Position | instrument, quantity, average entry, last sample price, unrealized P&L | Derived from simulated orders and bundled prices. |
| Activity record | id, event type, summary, timestamp | Local audit-style timeline for the training session. |
| Strategy reference | name, description, color theme, enabled state | Educational source content; not a trading signal or recommendation. |
| Session reference | name, primary markets, learning note | Static education context that never represents a live market schedule guarantee. |
| Cloud readiness | Supabase client configuration, schema state, Edge Function state | Public client configuration may be present; protected operations stay disabled until their server-side dependencies are verified. |

## Accessibility and Platform Fit

All controls use at least 44-point touch targets, typography avoids tightly packed financial figures, and loss/gain state never relies on color alone. The tab bar uses native symbol equivalents on iOS with a matched Android fallback. The interface will respect safe areas, keyboard movement on the trade ticket, and automatic light/dark theming while retaining the Bluezone visual hierarchy.
