import { Pressable, StyleSheet, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";

export function WorkspaceScreen({ eyebrow, title, children }: { eyebrow: string; title: string; children: React.ReactNode }) {
  const router = useRouter();
  return <ScreenContainer edges={["top", "bottom", "left", "right"]}><View style={styles.container}><Pressable accessibilityLabel="Back to previous screen" onPress={() => router.back()} style={({ pressed }) => [styles.back, pressed && styles.pressed]}><Text style={styles.backText}>‹ Back</Text></Pressable><Text style={styles.eyebrow}>{eyebrow}</Text><Text style={styles.title}>{title}</Text>{children}</View></ScreenContainer>;
}

export const workspaceStyles = StyleSheet.create({
  card: { backgroundColor: "#FFFFFF", borderColor: "#E6EBF1", borderRadius: 18, borderWidth: 1, marginBottom: 12, padding: 16 },
  cardTitle: { color: "#0B1220", fontSize: 16, fontWeight: "800" },
  copy: { color: "#64748B", fontSize: 13, lineHeight: 19, marginTop: 6 },
  label: { color: "#2563EB", fontSize: 11, fontWeight: "800", letterSpacing: 0.8 },
  pressed: { opacity: 0.7 },
});

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  back: { alignSelf: "flex-start", minHeight: 40, justifyContent: "center", paddingRight: 12 },
  backText: { color: "#2563EB", fontSize: 15, fontWeight: "800" },
  eyebrow: { color: "#2563EB", fontSize: 11, fontWeight: "800", letterSpacing: 1.2, marginTop: 6 },
  title: { color: "#0B1220", fontSize: 30, fontWeight: "800", letterSpacing: -0.8, marginBottom: 18, marginTop: 4 },
  pressed: { opacity: 0.7 },
});
