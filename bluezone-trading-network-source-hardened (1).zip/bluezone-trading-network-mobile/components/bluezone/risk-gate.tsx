import AsyncStorage from "@react-native-async-storage/async-storage";
import { usePathname, useRouter } from "expo-router";
import { useEffect, useState, type PropsWithChildren } from "react";
import { ActivityIndicator, View } from "react-native";

import { getActivationToken, getDeviceId } from "@/lib/device-activation";
import { requestDeviceLicense } from "@/lib/device-license-api";
import { withRequestTimeout } from "@/lib/owner-auth-feedback";
import { isPublicEntryRoute } from "@/lib/access-route-policy";

const RISK_KEY = "bluezone-risk-accepted-v1";

export function RiskGate({ children }: PropsWithChildren) {
  const router = useRouter();
  const pathname = usePathname();
  const [checked, setChecked] = useState(false);
  const normalizedPath = pathname.replace(/\/+$/, "") || "/";
  const isLicenseRoute = normalizedPath === "/license";
  const isRiskRoute = normalizedPath === "/risk-disclaimer";
  const isWelcomeRoute = isPublicEntryRoute(normalizedPath);
  const isOwnerRoute = normalizedPath === "/auth" || normalizedPath === "/license-admin";

  useEffect(() => {
    let active = true;
    const finish = () => { if (active) setChecked(true); };
    const redirect = (target: "/license" | "/risk-disclaimer" | "/(tabs)") => {
      finish();
      if (normalizedPath !== target) router.replace(target as never);
    };

    const enforce = async () => {
      if (isOwnerRoute || isWelcomeRoute) { finish(); return; }
      const token = await withRequestTimeout(getActivationToken(), "Loading activation");
      if (!token) { redirect("/license"); return; }

      const deviceId = await withRequestTimeout(getDeviceId(), "Preparing this device");
      const result = await requestDeviceLicense("status", token, deviceId);
      if (!active) return;
      if (!result.valid) { redirect("/license"); return; }

      if (isLicenseRoute) { redirect("/risk-disclaimer"); return; }
      const riskAccepted = await AsyncStorage.getItem(RISK_KEY).catch(() => null);
      if (!active) return;
      if (riskAccepted !== "yes") { redirect("/risk-disclaimer"); return; }
      if (isRiskRoute) { redirect("/(tabs)"); return; }
      finish();
    };

    enforce().catch(() => { if (!isOwnerRoute && !isWelcomeRoute) redirect("/license"); });
    return () => { active = false; };
  }, [isLicenseRoute, isOwnerRoute, isRiskRoute, isWelcomeRoute, normalizedPath, router]);

  return <>
    {children}
    {!checked ? <View pointerEvents="none" style={{ alignItems: "center", bottom: 0, justifyContent: "center", left: 0, position: "absolute", right: 0, top: 0 }}><ActivityIndicator color="#2563EB" /></View> : null}
  </>;
}

export async function acceptRiskDisclosure() { await AsyncStorage.setItem(RISK_KEY, "yes"); }
