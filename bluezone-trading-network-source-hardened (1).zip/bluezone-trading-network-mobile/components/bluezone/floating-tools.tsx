import { Pressable, StyleSheet, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { openSupport } from "@/lib/bluezone-workspace";

export function FloatingTools() {
  const router = useRouter();
  return <View pointerEvents="box-none" style={styles.root}><Pressable accessibilityLabel="Contact Bluezone support on WhatsApp" onPress={() => openSupport("support").catch(() => undefined)} style={({ pressed }) => [styles.support, pressed && styles.pressed]}><Text style={styles.supportText}>WA</Text></Pressable><Pressable accessibilityLabel="Open Bluezone educational assistant" onPress={() => router.push("/chat" as never)} style={({ pressed }) => [styles.chat, pressed && styles.pressed]}><Text style={styles.chatText}>AI</Text></Pressable></View>;
}
const styles = StyleSheet.create({ root: { bottom: 88, flexDirection: "row", justifyContent: "space-between", left: 18, position: "absolute", right: 18 }, support: { alignItems: "center", backgroundColor: "#0F9B8E", borderRadius: 24, elevation: 3, height: 48, justifyContent: "center", shadowColor: "#0B1220", shadowOpacity: 0.18, shadowRadius: 8, width: 48 }, chat: { alignItems: "center", backgroundColor: "#2563EB", borderRadius: 24, elevation: 3, height: 48, justifyContent: "center", shadowColor: "#0B1220", shadowOpacity: 0.18, shadowRadius: 8, width: 48 }, supportText: { color: "#FFFFFF", fontSize: 11, fontWeight: "900" }, chatText: { color: "#FFFFFF", fontSize: 12, fontWeight: "900" }, pressed: { opacity: 0.72, transform: [{ scale: 0.97 }] } });
