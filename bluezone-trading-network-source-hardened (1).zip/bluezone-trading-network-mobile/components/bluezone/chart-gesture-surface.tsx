import { type PropsWithChildren, useRef, useState } from "react";
import { StyleSheet, Text, View } from "react-native";
import { Gesture, GestureDetector } from "react-native-gesture-handler";
import Animated from "react-native-reanimated";
import { clampChartPan, clampChartScale, defaultChartGestureState } from "@/lib/chart-gesture-math";

export function ChartGestureSurface({ children }: PropsWithChildren) {
  const [scale, setScale] = useState(1); const [translateX, setTranslateX] = useState(0); const scaleRef = useRef(1); const translateRef = useRef(0); const pinchBaseRef = useRef(1); const panBaseRef = useRef(0);
  const updateScale = (next: number) => { const safe = clampChartScale(next); scaleRef.current = safe; setScale(safe); const correctedOffset = clampChartPan(translateRef.current, safe); if (correctedOffset !== translateRef.current) { translateRef.current = correctedOffset; setTranslateX(correctedOffset); } };
  const updatePan = (next: number) => { const safe = clampChartPan(next, scaleRef.current); translateRef.current = safe; setTranslateX(safe); };
  const reset = () => { const next = defaultChartGestureState(); scaleRef.current = next.scale; translateRef.current = next.translateX; setScale(next.scale); setTranslateX(next.translateX); };
  const pinch = Gesture.Pinch().onBegin(() => { pinchBaseRef.current = scaleRef.current; }).onUpdate((event) => updateScale(pinchBaseRef.current * event.scale)).runOnJS(true);
  const pan = Gesture.Pan().activeOffsetX([-8, 8]).failOffsetY([-12, 12]).onBegin(() => { panBaseRef.current = translateRef.current; }).onUpdate((event) => updatePan(panBaseRef.current + event.translationX)).runOnJS(true);
  const resetTap = Gesture.Tap().numberOfTaps(2).onEnd((_event, success) => { if (success) reset(); }).runOnJS(true);
  return <View style={styles.wrapper}><View style={styles.viewport}><GestureDetector gesture={Gesture.Simultaneous(pinch, pan, resetTap)}><Animated.View style={[styles.canvas, { transform: [{ scale }, { translateX }] }]}>{children}</Animated.View></GestureDetector></View><Text style={styles.hint}>Pinch to zoom · Drag horizontally to pan · Double tap to reset</Text></View>;
}

const styles = StyleSheet.create({ wrapper: { alignItems: "center" }, viewport: { overflow: "hidden", width: "100%" }, canvas: { alignItems: "center" }, hint: { color: "#94A3B8", fontSize: 10, marginTop: 6 } });
