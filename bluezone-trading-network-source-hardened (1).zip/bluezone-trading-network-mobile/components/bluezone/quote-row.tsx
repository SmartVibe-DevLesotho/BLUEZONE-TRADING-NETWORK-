import { Pressable, StyleSheet, Text, View } from "react-native";
import { formatPercent, formatPrice, type Quote } from "@/lib/bluezone-data";

export function QuoteRow({ quote, onPress, compact = false }: { quote: Quote; onPress: () => void; compact?: boolean }) {
  const isPositive = quote.changePercent >= 0;
  return <Pressable accessibilityHint={`Open the ${quote.symbol} training quote and simulated trade screen`} accessibilityLabel={`${quote.symbol}, ${quote.name}, ${formatPrice(quote)}, ${formatPercent(quote.changePercent)}`} onPress={onPress} style={({ pressed }) => [styles.row, compact && styles.compactRow, pressed && styles.rowPressed]}><View style={styles.symbolWrap}><Text style={styles.symbol}>{quote.symbol}</Text><Text style={styles.name}>{quote.name}</Text></View><View style={styles.priceWrap}><Text style={styles.price}>{formatPrice(quote)}</Text><Text style={[styles.change, isPositive ? styles.positive : styles.negative]}>{formatPercent(quote.changePercent)}</Text></View></Pressable>;
}

const styles = StyleSheet.create({
  row: { alignItems: "center", backgroundColor: "#FFFFFF", borderColor: "#E6EBF1", borderRadius: 18, borderWidth: 1, flexDirection: "row", justifyContent: "space-between", marginBottom: 10, minHeight: 78, paddingHorizontal: 16, paddingVertical: 14 }, compactRow: { minHeight: 72 }, rowPressed: { opacity: 0.72 }, symbolWrap: { flex: 1, paddingRight: 12 }, symbol: { color: "#0B1220", fontSize: 16, fontWeight: "800", letterSpacing: -0.1 }, name: { color: "#64748B", fontSize: 12, marginTop: 4 }, priceWrap: { alignItems: "flex-end" }, price: { color: "#0B1220", fontSize: 15, fontWeight: "700" }, change: { fontSize: 12, fontWeight: "800", marginTop: 4 }, positive: { color: "#0F9B8E" }, negative: { color: "#E5484D" },
});
