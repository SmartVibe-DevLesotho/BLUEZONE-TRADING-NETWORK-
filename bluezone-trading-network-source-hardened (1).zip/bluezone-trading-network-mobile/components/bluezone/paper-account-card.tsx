import { StyleSheet, Text, View } from "react-native";
import { formatMoney } from "@/lib/bluezone-data";
import type { AccountMetrics } from "@/lib/paper-engine";

export function PaperAccountCard({ metrics, compact = false }: { metrics: AccountMetrics; compact?: boolean }) {
  const pnlPositive = metrics.totalPnl >= 0;
  return <View style={[styles.card, compact && styles.compactCard]}><View style={styles.topRow}><Text style={styles.label}>PAPER ACCOUNT</Text><View style={styles.simulationPill}><View style={styles.dot} /><Text style={styles.simulationText}>PAPER MODE</Text></View></View><Text style={styles.balance}>{formatMoney(metrics.equity)}</Text><View style={styles.summaryRow}><View><Text style={styles.summaryLabel}>AVAILABLE CASH</Text><Text style={styles.summaryValue}>{formatMoney(metrics.cash)}</Text></View><View style={styles.summaryRight}><Text style={styles.summaryLabel}>TOTAL P&amp;L</Text><Text style={[styles.summaryValue, pnlPositive ? styles.positive : styles.negative]}>{pnlPositive ? "+" : ""}{formatMoney(metrics.totalPnl)}</Text></View></View></View>;
}

const styles = StyleSheet.create({
  card: { backgroundColor: "#0B1220", borderRadius: 24, padding: 20 }, compactCard: { paddingVertical: 18 }, topRow: { alignItems: "center", flexDirection: "row", justifyContent: "space-between" }, label: { color: "#94A3B8", fontSize: 11, fontWeight: "800", letterSpacing: 1.2 }, simulationPill: { alignItems: "center", backgroundColor: "#173446", borderRadius: 99, flexDirection: "row", paddingHorizontal: 9, paddingVertical: 5 }, dot: { backgroundColor: "#2DD4BF", borderRadius: 4, height: 7, marginRight: 5, width: 7 }, simulationText: { color: "#CFFAFE", fontSize: 9, fontWeight: "800", letterSpacing: 0.7 }, balance: { color: "#FFFFFF", fontSize: 32, fontWeight: "800", letterSpacing: -0.8, marginTop: 12 }, summaryRow: { borderTopColor: "#263647", borderTopWidth: 1, flexDirection: "row", justifyContent: "space-between", marginTop: 18, paddingTop: 14 }, summaryRight: { alignItems: "flex-end" }, summaryLabel: { color: "#94A3B8", fontSize: 9, fontWeight: "800", letterSpacing: 0.8 }, summaryValue: { color: "#E2E8F0", fontSize: 14, fontWeight: "700", marginTop: 5 }, positive: { color: "#5EEAD4" }, negative: { color: "#FDA4AF" },
});
