import AsyncStorage from "@react-native-async-storage/async-storage";
import { createContext, type PropsWithChildren, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";

import { type Quote } from "@/lib/bluezone-data";
import { createInitialPaperAccount, derivePositions, getAccountMetrics, submitPaperOrder, type PaperAccountState, type TradeSide } from "@/lib/paper-engine";
import type { TradingStyle } from "@/lib/bluezone-workspace";
import { trpc } from "@/lib/trpc";

const STORAGE_KEY = "bluezone-paper-account-v1";
const PREFERENCES_KEY = "bluezone-trading-preferences-v1";
type SessionName = "Sydney" | "Tokyo" | "London" | "New York";
type WorkspacePreferences = { selectedSymbol: string; selectedSession: SessionName; selectedStyle: TradingStyle; selectedStrategy: string; consensusThreshold: 4 | 6 | 8; signalWatchEnabled: boolean; signalWatchSymbols: string[] };

type PaperAccountContextValue = {
  account: PaperAccountState;
  positions: ReturnType<typeof derivePositions>;
  metrics: ReturnType<typeof getAccountMetrics>;
  isHydrated: boolean;
  quotes: Quote[];
  quoteFeed: { status: "loading" | "public" | "partial" | "unavailable"; provider: string; fetchedAt: string | null; unavailableSymbols: string[] };
  signals: Array<{ symbol: string; name: string; price: number; asOf: string; direction: "LONG_BIAS" | "SHORT_BIAS" | "WAIT" | "UNAVAILABLE"; strength: "STRONG" | "MODERATE" | "NONE"; alignmentScore: number; shortAverage: number | null; longAverage: number | null; momentumPercent: number | null; rsi14: number | null; invalidationReference: number | null; freshness: "fresh" | "stale"; inputs: string[]; rationale: string[]; disclaimer: string }>;
  signalFeed: { status: "loading" | "public" | "partial" | "unavailable"; provider: string; fetchedAt: string | null; unavailableSymbols: string[] };
  selectedSymbol: string;
  selectedSession: SessionName;
  selectedStyle: TradingStyle;
  selectedStrategy: string;
  consensusThreshold: 4 | 6 | 8;
  signalWatchEnabled: boolean;
  signalWatchSymbols: string[];
  setSelectedSymbol: (symbol: string) => void;
  setSelectedSession: (session: SessionName) => void;
  setSelectedStyle: (style: TradingStyle) => void;
  setSelectedStrategy: (strategy: string) => void;
  setConsensusThreshold: (threshold: 4 | 6 | 8) => void;
  setSignalWatchEnabled: (enabled: boolean) => void;
  toggleSignalWatchSymbol: (symbol: string) => void;
  executeTrade: (input: { symbol: string; side: TradeSide; quantity: number }) => ReturnType<typeof submitPaperOrder>;
  closePosition: (symbol: string) => ReturnType<typeof submitPaperOrder> | null;
  resetAccount: () => void;
};
const PaperAccountContext = createContext<PaperAccountContextValue | undefined>(undefined);

function isPaperAccountState(value: unknown): value is PaperAccountState {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Partial<PaperAccountState>;
  return typeof candidate.startingBalance === "number" && typeof candidate.cash === "number" && Array.isArray(candidate.orders) && Array.isArray(candidate.activity);
}

function isSessionName(value: unknown): value is SessionName { return value === "Sydney" || value === "Tokyo" || value === "London" || value === "New York"; }
function isTradingStyle(value: unknown): value is TradingStyle { return value === "Scalping" || value === "Day Trading" || value === "Swing Trading" || value === "Positional Trading"; }

export function PaperAccountProvider({ children }: PropsWithChildren) {
  const initialAccount = useMemo(() => createInitialPaperAccount(), []);
  const [account, setAccount] = useState<PaperAccountState>(initialAccount);
  const [isHydrated, setIsHydrated] = useState(false);
  const [selectedSymbol, setSelectedSymbol] = useState("XAUUSD");
  const [selectedSession, setSelectedSession] = useState<SessionName>("London");
  const [selectedStyle, setSelectedStyle] = useState<TradingStyle>("Day Trading");
  const [selectedStrategy, setSelectedStrategy] = useState("CRT Range Reversal");
  const [consensusThreshold, setConsensusThreshold] = useState<4 | 6 | 8>(6);
  const [signalWatchEnabled, setSignalWatchEnabled] = useState(false);
  const [signalWatchSymbols, setSignalWatchSymbols] = useState<string[]>(["XAUUSD", "EURUSD"]);
  const accountRef = useRef(account);
  const liveQuotesQuery = trpc.market.quotes.useQuery(undefined, { refetchInterval: 60_000, staleTime: 45_000, retry: 1, refetchOnReconnect: true });
  const liveSignalsQuery = trpc.market.signals.useQuery(undefined, { refetchInterval: 60_000, staleTime: 45_000, retry: 1, refetchOnReconnect: true });

  useEffect(() => {
    let active = true;
    async function hydrate() {
      try {
        const saved = await AsyncStorage.getItem(STORAGE_KEY);
        if (!saved || !active) return;
        const parsed = JSON.parse(saved) as unknown;
        if (isPaperAccountState(parsed)) { accountRef.current = parsed; setAccount(parsed); }
      } catch { /* corrupt persistence starts a safe new training session */ } finally { if (active) setIsHydrated(true); }
    }
    hydrate();
    return () => { active = false; };
  }, []);

  useEffect(() => {
    AsyncStorage.getItem(PREFERENCES_KEY).then((raw) => {
      if (!raw) return;
      const parsed = JSON.parse(raw) as Partial<WorkspacePreferences>;
      if (typeof parsed.selectedSymbol === "string") setSelectedSymbol(parsed.selectedSymbol);
      if (isSessionName(parsed.selectedSession)) setSelectedSession(parsed.selectedSession);
      if (isTradingStyle(parsed.selectedStyle)) setSelectedStyle(parsed.selectedStyle);
      if (typeof parsed.selectedStrategy === "string") setSelectedStrategy(parsed.selectedStrategy);
      if (parsed.consensusThreshold === 4 || parsed.consensusThreshold === 6 || parsed.consensusThreshold === 8) setConsensusThreshold(parsed.consensusThreshold);
      if (typeof parsed.signalWatchEnabled === "boolean") setSignalWatchEnabled(parsed.signalWatchEnabled);
      if (Array.isArray(parsed.signalWatchSymbols) && parsed.signalWatchSymbols.every((symbol) => typeof symbol === "string")) setSignalWatchSymbols(parsed.signalWatchSymbols);
    }).catch(() => undefined);
  }, []);

  useEffect(() => { accountRef.current = account; if (isHydrated) AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(account)).catch(() => undefined); }, [account, isHydrated]);
  useEffect(() => { AsyncStorage.setItem(PREFERENCES_KEY, JSON.stringify({ selectedSymbol, selectedSession, selectedStyle, selectedStrategy, consensusThreshold, signalWatchEnabled, signalWatchSymbols })).catch(() => undefined); }, [selectedSymbol, selectedSession, selectedStyle, selectedStrategy, consensusThreshold, signalWatchEnabled, signalWatchSymbols]);

  const quotes = useMemo<Quote[]>(() => liveQuotesQuery.data?.quotes ?? [], [liveQuotesQuery.data]);
  const quoteFeed = useMemo<PaperAccountContextValue["quoteFeed"]>(() => {
    if (liveQuotesQuery.isLoading) return { status: "loading", provider: "Public quote source", fetchedAt: null, unavailableSymbols: [] };
    if (liveQuotesQuery.data) return { status: liveQuotesQuery.data.status, provider: liveQuotesQuery.data.provider, fetchedAt: liveQuotesQuery.data.fetchedAt, unavailableSymbols: liveQuotesQuery.data.unavailableSymbols };
    return { status: "unavailable", provider: "Public quote source", fetchedAt: null, unavailableSymbols: [] };
  }, [liveQuotesQuery.data, liveQuotesQuery.isLoading]);
  const signals = useMemo<PaperAccountContextValue["signals"]>(() => liveSignalsQuery.data?.signals ?? [], [liveSignalsQuery.data]);
  const signalFeed = useMemo<PaperAccountContextValue["signalFeed"]>(() => {
    if (liveSignalsQuery.isLoading) return { status: "loading", provider: "Public market history", fetchedAt: null, unavailableSymbols: [] };
    if (liveSignalsQuery.data) return { status: liveSignalsQuery.data.status, provider: liveSignalsQuery.data.provider, fetchedAt: liveSignalsQuery.data.fetchedAt, unavailableSymbols: liveSignalsQuery.data.unavailableSymbols };
    return { status: "unavailable", provider: "Public market history", fetchedAt: null, unavailableSymbols: [] };
  }, [liveSignalsQuery.data, liveSignalsQuery.isLoading]);
  const quotesRef = useRef(quotes);
  useEffect(() => { quotesRef.current = quotes; }, [quotes]);
  const executeTrade = useCallback<PaperAccountContextValue["executeTrade"]>((input) => {
    const result = submitPaperOrder(accountRef.current, quotesRef.current, input);
    if (result.success) { accountRef.current = result.account; setAccount(result.account); }
    return result;
  }, []);
  const closePosition = useCallback<PaperAccountContextValue["closePosition"]>((symbol) => {
    const position = derivePositions(accountRef.current, quotesRef.current).find((candidate) => candidate.symbol === symbol);
    return position ? executeTrade({ symbol, side: "sell", quantity: position.quantity }) : null;
  }, [executeTrade]);
  const toggleSignalWatchSymbol = useCallback((symbol: string) => setSignalWatchSymbols((current) => current.includes(symbol) ? current.filter((candidate) => candidate !== symbol) : [...current, symbol]), []);
  const resetAccount = useCallback(() => {
    const reset = createInitialPaperAccount();
    reset.activity = [{ id: `reset-${Date.now()}`, kind: "reset", title: "Paper account reset", detail: "The $10,000 training balance and local order history were restarted.", createdAt: new Date().toISOString() }];
    accountRef.current = reset;
    setAccount(reset);
  }, []);
  const positions = useMemo(() => derivePositions(account, quotes), [account, quotes]);
  const metrics = useMemo(() => getAccountMetrics(account, quotes), [account, quotes]);
  const value = useMemo(() => ({ account, positions, metrics, isHydrated, quotes, quoteFeed, signals, signalFeed, selectedSymbol, selectedSession, selectedStyle, selectedStrategy, consensusThreshold, signalWatchEnabled, signalWatchSymbols, setSelectedSymbol, setSelectedSession, setSelectedStyle, setSelectedStrategy, setConsensusThreshold, setSignalWatchEnabled, toggleSignalWatchSymbol, executeTrade, closePosition, resetAccount }), [account, positions, metrics, isHydrated, quotes, quoteFeed, signals, signalFeed, selectedSymbol, selectedSession, selectedStyle, selectedStrategy, consensusThreshold, signalWatchEnabled, signalWatchSymbols, executeTrade, closePosition, toggleSignalWatchSymbol, resetAccount]);
  return <PaperAccountContext.Provider value={value}>{children}</PaperAccountContext.Provider>;
}

export function usePaperAccount() {
  const context = useContext(PaperAccountContext);
  if (!context) throw new Error("usePaperAccount must be used within PaperAccountProvider.");
  return context;
}
