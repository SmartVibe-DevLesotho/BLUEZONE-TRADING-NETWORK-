export type LiveSignalDirection = "LONG_BIAS" | "SHORT_BIAS" | "WAIT" | "UNAVAILABLE";
export type LiveSignalStrength = "STRONG" | "MODERATE" | "NONE";

export type LiveSignalAssessment = {
  direction: LiveSignalDirection;
  strength: LiveSignalStrength;
  alignmentScore: number;
  freshness: "fresh" | "stale";
  shortAverage: number | null;
  longAverage: number | null;
  momentumPercent: number | null;
  rsi14: number | null;
  invalidationReference: number | null;
  inputs: string[];
  rationale: string[];
};

function isFiniteNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

function average(values: number[]) {
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function rsi14(closes: number[]) {
  if (closes.length < 15) return null;
  let gains = 0;
  let losses = 0;
  for (let index = 1; index <= 14; index += 1) {
    const change = closes[index] - closes[index - 1];
    gains += Math.max(change, 0);
    losses += Math.max(-change, 0);
  }
  let averageGain = gains / 14;
  let averageLoss = losses / 14;
  for (let index = 15; index < closes.length; index += 1) {
    const change = closes[index] - closes[index - 1];
    averageGain = (averageGain * 13 + Math.max(change, 0)) / 14;
    averageLoss = (averageLoss * 13 + Math.max(-change, 0)) / 14;
  }
  if (averageLoss === 0) return 100;
  return 100 - 100 / (1 + averageGain / averageLoss);
}

export function evaluateLiveSignal(input: { closes: number[]; asOf: string; now?: number; maxAgeMs?: number }): LiveSignalAssessment {
  const closes = input.closes.filter(isFiniteNumber);
  const last = closes.at(-1) ?? 0;
  const prior = closes.at(-6) ?? null;
  const shortWindow = closes.slice(-5);
  const longWindow = closes.slice(-20);
  const inputs = ["5-period versus 20-period moving-average direction", "5-period momentum", "RSI 14 regime", "public-source freshness"];
  if (!last || prior === null || prior === 0 || shortWindow.length < 5 || longWindow.length < 20) {
    return { direction: "UNAVAILABLE", strength: "NONE", alignmentScore: 0, freshness: "stale", shortAverage: null, longAverage: null, momentumPercent: null, rsi14: null, invalidationReference: null, inputs, rationale: ["Insufficient provider-returned history for an assessed signal."] };
  }

  const shortAverage = average(shortWindow);
  const longAverage = average(longWindow);
  const momentumPercent = ((last - prior) / prior) * 100;
  const rsi = rsi14(closes);
  const asOfMs = Date.parse(input.asOf);
  const freshness = Number.isFinite(asOfMs) && (input.now ?? Date.now()) - asOfMs <= (input.maxAgeMs ?? 15 * 60_000) ? "fresh" : "stale";
  if (freshness === "stale") {
    return { direction: "WAIT", strength: "NONE", alignmentScore: 0, freshness, shortAverage, longAverage, momentumPercent, rsi14: rsi, invalidationReference: null, inputs, rationale: ["Public market history is stale, so Bluezone withholds directional research."] };
  }
  if (rsi === null) {
    return { direction: "UNAVAILABLE", strength: "NONE", alignmentScore: 0, freshness, shortAverage, longAverage, momentumPercent, rsi14: null, invalidationReference: null, inputs, rationale: ["RSI needs at least 15 complete provider-returned closes."] };
  }

  const longVotes = [shortAverage > longAverage, momentumPercent > 0, rsi >= 52 && rsi <= 70].filter(Boolean).length;
  const shortVotes = [shortAverage < longAverage, momentumPercent < 0, rsi >= 30 && rsi <= 48].filter(Boolean).length;
  const extremeMomentum = rsi > 70 || rsi < 30;
  if (extremeMomentum || (longVotes < 2 && shortVotes < 2)) {
    return { direction: "WAIT", strength: "NONE", alignmentScore: Math.max(longVotes, shortVotes) * 25, freshness, shortAverage, longAverage, momentumPercent, rsi14: rsi, invalidationReference: null, inputs, rationale: [extremeMomentum ? "RSI is outside the method’s trend-following regime; the engine waits rather than chases an extended move." : "Trend, momentum, and RSI do not show enough directional alignment."] };
  }

  const direction: LiveSignalDirection = longVotes > shortVotes ? "LONG_BIAS" : "SHORT_BIAS";
  const votes = Math.max(longVotes, shortVotes);
  const strength: LiveSignalStrength = votes === 3 ? "STRONG" : "MODERATE";
  const alignmentScore = votes === 3 ? 85 : 65;
  const invalidationReference = direction === "LONG_BIAS" ? Math.min(...shortWindow) : Math.max(...shortWindow);
  const rationale = direction === "LONG_BIAS"
    ? [`${votes}/3 method inputs align upward.`, `Fast average is above the slow average; recent momentum is ${momentumPercent.toFixed(3)}%.`, `RSI 14 is ${rsi.toFixed(1)} within the method’s long-bias regime.`]
    : [`${votes}/3 method inputs align downward.`, `Fast average is below the slow average; recent momentum is ${momentumPercent.toFixed(3)}%.`, `RSI 14 is ${rsi.toFixed(1)} within the method’s short-bias regime.`];
  return { direction, strength, alignmentScore, freshness, shortAverage, longAverage, momentumPercent, rsi14: rsi, invalidationReference, inputs, rationale };
}
