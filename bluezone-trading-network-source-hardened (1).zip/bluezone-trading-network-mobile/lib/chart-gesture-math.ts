export const MIN_CHART_SCALE = 1;
export const MAX_CHART_SCALE = 2.6;
const PAN_DISTANCE_AT_MAX_SCALE = 130;

export function clampChartScale(next: number) {
  return Math.max(MIN_CHART_SCALE, Math.min(MAX_CHART_SCALE, next));
}

export function chartPanLimit(scale: number) {
  return PAN_DISTANCE_AT_MAX_SCALE * (clampChartScale(scale) - 1);
}

export function clampChartPan(next: number, scale: number) {
  const limit = chartPanLimit(scale);
  return Math.max(-limit, Math.min(limit, next));
}

export function defaultChartGestureState() {
  return { scale: MIN_CHART_SCALE, translateX: 0 };
}
