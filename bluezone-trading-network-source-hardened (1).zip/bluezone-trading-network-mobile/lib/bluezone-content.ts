export type ContentCategory = "Forex" | "Metals" | "Crypto" | "Indices" | "Deriv";

const pairs = ["EURUSD", "GBPUSD", "USDJPY", "USDCHF", "AUDUSD", "USDCAD", "NZDUSD", "EURGBP", "EURJPY", "GBPJPY", "EURCHF", "AUDJPY", "EURAUD", "GBPAUD", "GBPCAD", "EURCAD", "NZDJPY", "CADJPY", "CHFJPY", "AUDCAD", "AUDNZD", "AUDCHF", "GBPNZD", "EURNZD", "GBPCHF", "CADCHF", "NZDCAD", "NZDCHF"];
const metals = [["XAUUSD", "Gold / US Dollar"], ["XAGUSD", "Silver / US Dollar"], ["XPTUSD", "Platinum / US Dollar"]] as const;
const crypto = [["BTCUSD", "Bitcoin / US Dollar"], ["ETHUSD", "Ethereum / US Dollar"], ["LTCUSD", "Litecoin / US Dollar"], ["XRPUSD", "XRP / US Dollar"], ["LINKUSD", "Chainlink / US Dollar"], ["BNBUSD", "BNB / US Dollar"], ["SOLUSD", "Solana / US Dollar"]] as const;
const indices = [["US30", "Dow Jones 30"], ["US500", "S&P 500"], ["US100", "Nasdaq 100"], ["UK100", "FTSE 100"], ["GER40", "Germany 40"], ["JPN225", "Japan 225"], ["AUS200", "Australia 200"]] as const;
const deriv = ["V10", "V25", "V50", "V75", "V100", "Crash 300", "Crash 500", "Crash 1000", "Boom 300", "Boom 500", "Boom 1000", "Step Index", "Jump 10", "Jump 25", "Jump 50", "Jump 75", "Jump 100", "Range Break 100", "Range Break 200", "DEX 600 UP", "DEX 900 DOWN"];
const liveSymbols = new Set(["XAUUSD", "EURUSD", "GBPUSD", "USDJPY", "BTCUSD", "US30"]);

export type MarketCatalogItem = { symbol: string; name: string; category: ContentCategory; quoteAvailability: "public" | "training" };
export const marketCatalog: MarketCatalogItem[] = [
  ...pairs.map((symbol) => ({ symbol, name: symbol, category: "Forex" as const, quoteAvailability: liveSymbols.has(symbol) ? "public" as const : "training" as const })),
  ...metals.map(([symbol, name]) => ({ symbol, name, category: "Metals" as const, quoteAvailability: liveSymbols.has(symbol) ? "public" as const : "training" as const })),
  ...crypto.map(([symbol, name]) => ({ symbol, name, category: "Crypto" as const, quoteAvailability: liveSymbols.has(symbol) ? "public" as const : "training" as const })),
  ...indices.map(([symbol, name]) => ({ symbol, name, category: "Indices" as const, quoteAvailability: liveSymbols.has(symbol) ? "public" as const : "training" as const })),
  ...deriv.map((symbol) => ({ symbol, name: symbol, category: "Deriv" as const, quoteAvailability: "training" as const })),
];

export const strategies = [
  ["CRT Range Reversal", "Range accumulation, manipulation and distribution reversal strategy.", "Blue"],
  ["AMD Session Cycle", "Accumulation, manipulation and distribution session-cycle strategy.", "Indigo"],
  ["Turtle Soup / KOD", "Liquidity sweep and reversal methodology.", "Violet"],
  ["Validated Order Block", "Order-block based structure and confirmation strategy.", "Teal"],
  ["Malaysian SNR", "Support and resistance based trading methodology.", "Amber"],
  ["Trendline Break and Retest", "Breakout followed by structural retest confirmation.", "Cyan"],
  ["FVG Retest", "Fair Value Gap retracement and continuation strategy.", "Red"],
  ["Falcon Nature Structure", "Market structure and directional continuation methodology.", "Gray"],
] as const;

export const sessions = [
  ["Asia", "A quieter reference period often used to observe overnight ranges and liquidity context."],
  ["London", "A major European market session that users may choose as paper-trading practice context."],
  ["New York", "A major U.S. market session that can overlap with London and is presented here for learning only."],
] as const;

export const educationModules = [
  ["Trading 101", "What is Forex?", "Forex is the global market where currencies are exchanged against each other."],
  ["Trading 101", "What is a Pip?", "A pip is a standard unit used to measure price movement in many currency pairs."],
  ["Trading 101", "What is Leverage?", "Leverage can increase exposure and can increase both potential gains and losses."],
  ["Risk Management", "The 1% Rule", "Risk limits are personal decisions. This common teaching example is educational, not a recommendation or guarantee."],
  ["Risk Management", "Risk / Reward", "Risk/reward compares an estimated potential loss with a potential gain for a hypothetical trade."],
  ["Risk Management", "Position Sizing", "Position sizing considers account size, stop-loss distance, and acceptable risk in a training scenario."],
  ["Trading Styles", "Scalping", "Scalping is a short-duration trading style often associated with lower timeframes."],
  ["Trading Styles", "Day Trading", "Day trading commonly describes opening and closing positions within the same day."],
  ["Trading Styles", "Swing Trading", "Swing trading can aim to follow broader moves over multiple days or weeks."],
] as const;
