export function ownerAuthMessage(error: unknown) {
  const message = error instanceof Error ? error.message : String(error ?? "");
  const normalized = message.toLowerCase();
  if (normalized.includes("email not confirmed") || normalized.includes("email not verified")) return "Your owner email is not confirmed. Tap “Resend confirmation email”, then open the link sent to your inbox or spam folder.";
  if (normalized.includes("invalid login credentials")) return "The owner email or password is incorrect. If the account was just created, confirm the owner email before signing in.";
  if (normalized.includes("timed out")) return "The owner sign-in request timed out. Check the connection and try again.";
  return message || "Owner sign-in could not be completed. Please try again.";
}

export async function withOwnerAuthTimeout<T>(request: Promise<T>, milliseconds = 15_000) {
  let timeout: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      request,
      new Promise<T>((_, reject) => { timeout = setTimeout(() => reject(new Error("Owner sign-in timed out.")), milliseconds); }),
    ]);
  } finally {
    if (timeout) clearTimeout(timeout);
  }
}

export async function withRequestTimeout<T>(request: Promise<T>, operation: string, milliseconds = 15_000) {
  let timeout: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      request,
      new Promise<T>((_, reject) => { timeout = setTimeout(() => reject(new Error(`${operation} timed out. Please try again.`)), milliseconds); }),
    ]);
  } finally {
    if (timeout) clearTimeout(timeout);
  }
}
