import { Linking } from "react-native";

export * from "@/lib/bluezone-core";
import { publicSupportUrl } from "@/lib/bluezone-core";

export async function openSupport(topic: "support" | "license") {
  return Linking.openURL(publicSupportUrl(topic));
}
