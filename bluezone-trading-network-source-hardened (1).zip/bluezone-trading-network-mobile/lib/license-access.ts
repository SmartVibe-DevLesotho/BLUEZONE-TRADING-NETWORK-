export type LicenseAccessRecord = {
  active: boolean;
  expiresAt: string | null;
  revokedAt?: string | null;
};

export function hasActiveLicense(records: LicenseAccessRecord[], now = Date.now()) {
  return records.some((record) => record.active && !record.revokedAt && (!record.expiresAt || Date.parse(record.expiresAt) > now));
}

export function activationMessage(record: LicenseAccessRecord | null, now = Date.now()) {
  if (!record || !record.active || record.revokedAt) return "An active owner-issued activation token is required.";
  if (record.expiresAt && Date.parse(record.expiresAt) <= now) return "Your activation token has expired. Request a renewal token from Bluezone.";
  return "Activation is active.";
}
