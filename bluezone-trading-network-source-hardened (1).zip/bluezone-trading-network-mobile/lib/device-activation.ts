import * as Crypto from "expo-crypto";
import * as SecureStore from "expo-secure-store";
import { Platform } from "react-native";

const DEVICE_KEY = "bluezone-device-id-v1";
const TOKEN_KEY = "bluezone-activation-token-v1";

async function getItem(key: string) {
  if (Platform.OS === "web") return globalThis.localStorage?.getItem(key) ?? null;
  return SecureStore.getItemAsync(key);
}

async function setItem(key: string, value: string) {
  if (Platform.OS === "web") { globalThis.localStorage?.setItem(key, value); return; }
  await SecureStore.setItemAsync(key, value);
}

export async function getDeviceId() {
  const existing = await getItem(DEVICE_KEY);
  if (existing) return existing;
  const deviceId = Crypto.randomUUID();
  await setItem(DEVICE_KEY, deviceId);
  return deviceId;
}

export async function getActivationToken() {
  return getItem(TOKEN_KEY);
}

export async function saveActivationToken(token: string) {
  await setItem(TOKEN_KEY, token.trim());
}

export async function clearActivationToken() {
  if (Platform.OS === "web") { globalThis.localStorage?.removeItem(TOKEN_KEY); return; }
  await SecureStore.deleteItemAsync(TOKEN_KEY);
}
