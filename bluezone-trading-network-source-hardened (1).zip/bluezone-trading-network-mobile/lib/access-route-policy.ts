export function isPublicEntryRoute(pathname: string) {
  const normalizedPath = pathname.replace(/\/+$/, "") || "/";
  return normalizedPath === "/" || normalizedPath === "/welcome" || normalizedPath === "/client-access";
}
