export type AlertEligibleSignal = {
  symbol: string;
  direction: "LONG_BIAS" | "SHORT_BIAS";
  strength: "STRONG" | "MODERATE";
  alignmentScore: number;
  asOf: string;
  rationale: string[];
};

export type SignalAlertEvent = AlertEligibleSignal & {
  dedupeKey: string;
  title: string;
  body: string;
};

export function selectAlertEligibleSignals(input: { signals: Array<{ symbol: string; direction: "LONG_BIAS" | "SHORT_BIAS" | "WAIT" | "UNAVAILABLE"; strength: "STRONG" | "MODERATE" | "NONE"; alignmentScore: number; freshness: "fresh" | "stale"; asOf: string; rationale: string[] }>; watchedSymbols: string[]; minAlignment: number; enabled: boolean }) {
  if (!input.enabled) return [];
  const watched = new Set(input.watchedSymbols);
  return input.signals.flatMap((signal): AlertEligibleSignal[] => {
    if (!watched.has(signal.symbol) || signal.freshness !== "fresh" || signal.alignmentScore < input.minAlignment || (signal.direction !== "LONG_BIAS" && signal.direction !== "SHORT_BIAS") || signal.strength === "NONE") return [];
    return [{ symbol: signal.symbol, direction: signal.direction, strength: signal.strength, alignmentScore: signal.alignmentScore, asOf: signal.asOf, rationale: signal.rationale }];
  });
}

export function toSignalAlertEvent(signal: AlertEligibleSignal): SignalAlertEvent {
  const direction = signal.direction === "LONG_BIAS" ? "Long bias" : "Short bias";
  return { ...signal, dedupeKey: `${signal.symbol}:${signal.direction}:${signal.asOf}`, title: `${signal.symbol} ${direction}`, body: `${signal.strength.toLowerCase()} alignment at ${signal.alignmentScore}%. Open Bluezone to review live source details and no-trade conditions.` };
}
