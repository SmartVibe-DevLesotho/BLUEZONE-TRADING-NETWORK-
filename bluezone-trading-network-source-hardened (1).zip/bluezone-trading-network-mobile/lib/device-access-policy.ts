export type DeviceActivationResult = { valid: boolean; expiresAt: string | null; message: string };

export function normalizeDeviceActivationResult(payload: unknown, fallbackMessage = "The activation service did not return a usable result."): DeviceActivationResult {
  if (!payload || typeof payload !== "object") {
    return { valid: false, expiresAt: null, message: fallbackMessage };
  }
  const record = payload as Record<string, unknown>;
  const message = typeof record.message === "string" && record.message.trim()
    ? record.message.trim()
    : fallbackMessage;
  return {
    valid: record.valid === true,
    expiresAt: typeof record.expiresAt === "string" ? record.expiresAt : null,
    message,
  };
}

export function deviceAccessMessage(result: DeviceActivationResult, now = Date.now()) {
  if (!result.valid) return result.message;
  if (result.expiresAt && Date.parse(result.expiresAt) <= now) return "This token has expired. Enter a renewal token from Bluezone.";
  return "Device activation is active.";
}

export function shouldStoreActivation(result: DeviceActivationResult) {
  return result.valid && (!result.expiresAt || Date.parse(result.expiresAt) > Date.now());
}
