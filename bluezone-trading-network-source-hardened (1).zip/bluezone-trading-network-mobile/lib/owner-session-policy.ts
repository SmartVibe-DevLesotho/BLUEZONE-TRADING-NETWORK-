export const OWNER_SIGN_OUT_TARGET = "/license";

type OwnerSignOutResult = { error?: unknown | null };

/** Ends the owner-only Supabase session. Device activation storage is intentionally untouched. */
export async function signOutOwnerSession(signOut: () => Promise<OwnerSignOutResult>) {
  const result = await signOut();
  if (result.error) throw result.error;
  return OWNER_SIGN_OUT_TARGET;
}
