export const DEVELOPER = {
  name: "Tseliso Sefale",
  email: "smartvibeslesotho@gmail.com",
  phone: "+266 6264 9248",
  whatsapp: "26662649248",
} as const;

export const BROKERS = [
  ["XM Group", "FSCA, CySEC, ASIC", "$5", "$1 (micro)", "https://www.xm.com/"], ["Exness", "FSCA, FCA, CySEC", "$1", "$0.01 lot", "https://www.exness.com/"], ["HFM", "FSCA, FCA, CySEC", "$5", "$1", "https://www.hfm.com/"], ["FXTM", "FSCA, FCA, CySEC", "$10", "$1", "https://www.forextime.com/"], ["Octa", "FSCA, CySEC", "$25", "$1", "https://www.octafx.com/"], ["FBS", "FSCA, CySEC, IFSC", "$1", "$1", "https://fbs.com/"], ["IC Markets", "ASIC, CySEC, SCB", "$200", "$0", "https://www.icmarkets.com/"], ["Pepperstone", "FSCA, ASIC, FCA", "$0", "$0", "https://pepperstone.com/"], ["AvaTrade", "FSCA, ASIC, FSA", "$100", "$1", "https://www.avatrade.com/"], ["Deriv", "MFSA, VFSC, LFSA", "$5", "$0.35", "https://deriv.com/"], ["Weltrade", "IFSC", "$1", "$1", "https://www.weltrade.com/"], ["InstaForex", "CySEC, BVI FSC", "$1", "$0.01 lot", "https://www.instaforex.com/"], ["Plus500", "FSCA, FCA, CySEC", "$100", "Varies", "https://www.plus500.com/"],
] as const;

export const SESSION_CARDS = [["Sydney", 22, 7, "AUDUSD, NZDUSD, AUDNZD"], ["Tokyo", 0, 9, "USDJPY, EURJPY, GBPJPY"], ["London", 8, 17, "EURUSD, GBPUSD, EURGBP"], ["New York", 13, 22, "EURUSD, GBPUSD, USDCAD"]] as const;
export const STYLE_REFERENCE = { Scalping: "M1, M5 · 1–30 min", "Day Trading": "M15, H1 · hours", "Swing Trading": "H4, D1 · days to weeks", "Positional Trading": "W1, MN · weeks to months" } as const;
export type TradingStyle = keyof typeof STYLE_REFERENCE;

export function publicSupportUrl(topic: "support" | "license") { const text = topic === "license" ? "Hi Tseliso, I'd like to buy a BlueZone license token." : "Hi Tseliso, I need help with BlueZone Trading Network."; return `https://wa.me/${DEVELOPER.whatsapp}?text=${encodeURIComponent(text)}`; }
export function trainingPrice(symbol: string) { const total = Array.from(symbol).reduce((sum, char) => sum + char.charCodeAt(0), 0); return Number(((total * 1.37) % 900 + 40).toFixed(2)); }
export function trainingChange(symbol: string) { const total = Array.from(symbol).reduce((sum, char) => sum + char.charCodeAt(0), 0); return Number((((total % 11) - 5) * 0.18).toFixed(2)); }
export function educationalReply(message: string) { const prompt = message.toLowerCase(); if (prompt.includes("pip")) return "A pip is a common unit for describing price movement in many currency pairs. It is an educational measurement, not a prediction."; if (prompt.includes("scalp")) return "Scalping is a short-duration style often associated with lower timeframes. It can involve rapid decisions and significant risk."; if (prompt.includes("robot") || prompt.includes("mt5")) return "Bluezone currently keeps robot automation disabled. The app does not connect to MT5, collect broker passwords, or submit broker orders."; if (prompt.includes("gold") || prompt.includes("xau")) return "Gold in Bluezone can display a public provider quote when available. Public data may be delayed or unavailable, and paper orders remain simulated."; return "Bluezone is a paper-trading and education workspace. I can explain app features, market terms, strategies, sessions, and risk concepts, but I do not provide guaranteed signals or execute trades."; }
