export type Quote = {
  symbol: string;
  name: string;
  price: number;
  changePercent: number;
  assetClass: "Metal" | "FX" | "Crypto" | "Index";
  providerSymbol?: string;
  provider?: string;
  origin?: "bundled" | "public";
  asOf?: string;
};

export const sampleQuotes: Quote[] = [
  { symbol: "XAUUSD", name: "Gold", price: 2338.42, changePercent: 0.84, assetClass: "Metal", origin: "bundled" },
  { symbol: "EURUSD", name: "Euro / Dollar", price: 1.0842, changePercent: 0.21, assetClass: "FX", origin: "bundled" },
  { symbol: "GBPUSD", name: "Pound / Dollar", price: 1.2718, changePercent: -0.14, assetClass: "FX", origin: "bundled" },
  { symbol: "USDJPY", name: "Dollar / Yen", price: 156.42, changePercent: 0.32, assetClass: "FX", origin: "bundled" },
  { symbol: "BTCUSD", name: "Bitcoin", price: 67420, changePercent: 1.82, assetClass: "Crypto", origin: "bundled" },
  { symbol: "US30", name: "Dow Jones", price: 39842, changePercent: 0.44, assetClass: "Index", origin: "bundled" },
];

export const quoteBySymbol = (symbol: string) => sampleQuotes.find((quote) => quote.symbol === symbol.toUpperCase());

export function formatMoney(value: number, maximumFractionDigits = 2) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2, maximumFractionDigits }).format(value);
}

export function formatPrice(quote: Quote) {
  if (quote.symbol === "BTCUSD" || quote.symbol === "US30") return new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 }).format(quote.price);
  if (quote.symbol === "EURUSD" || quote.symbol === "GBPUSD") return quote.price.toFixed(4);
  return quote.price.toFixed(2);
}

export function formatPercent(value: number) {
  return `${value >= 0 ? "+" : ""}${value.toFixed(2)}%`;
}
