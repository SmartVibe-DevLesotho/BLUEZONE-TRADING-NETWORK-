import type { Quote } from "@/lib/bluezone-data";

export type TradeSide = "buy" | "sell";
export type PaperOrder = { id: string; symbol: string; side: TradeSide; quantity: number; price: number; notional: number; createdAt: string; status: "simulated" };
export type ActivityItem = { id: string; kind: "trade" | "reset" | "system"; title: string; detail: string; createdAt: string };
export type PaperAccountState = { startingBalance: number; cash: number; orders: PaperOrder[]; activity: ActivityItem[] };
export type Position = { symbol: string; name: string; quantity: number; averageEntry: number; lastPrice: number; marketValue: number; unrealizedPnl: number };
export type AccountMetrics = { cash: number; equity: number; investedValue: number; unrealizedPnl: number; realizedPnl: number; totalPnl: number };
export type TradeResult = { success: true; account: PaperAccountState; order: PaperOrder } | { success: false; error: string };

export const STARTING_BALANCE = 10000;

export const createInitialPaperAccount = (): PaperAccountState => ({
  startingBalance: STARTING_BALANCE,
  cash: STARTING_BALANCE,
  orders: [],
  activity: [{ id: "system-ready", kind: "system", title: "Paper account ready", detail: "Your $10,000 practice balance is available locally on this device.", createdAt: new Date().toISOString() }],
});

export function derivePositions(account: PaperAccountState, quotes: Quote[]): Position[] {
  const bySymbol = new Map(quotes.map((quote) => [quote.symbol, quote]));
  const positionBook = new Map<string, { quantity: number; averageEntry: number }>();
  for (const order of account.orders) {
    const current = positionBook.get(order.symbol) ?? { quantity: 0, averageEntry: 0 };
    if (order.side === "buy") {
      const nextQuantity = current.quantity + order.quantity;
      const nextAverage = (current.quantity * current.averageEntry + order.quantity * order.price) / nextQuantity;
      positionBook.set(order.symbol, { quantity: nextQuantity, averageEntry: nextAverage });
    } else {
      positionBook.set(order.symbol, { quantity: Math.max(0, current.quantity - order.quantity), averageEntry: current.quantity - order.quantity <= 0 ? 0 : current.averageEntry });
    }
  }
  return Array.from(positionBook.entries()).flatMap(([symbol, position]) => {
    const quote = bySymbol.get(symbol);
    if (!quote || position.quantity <= 0) return [];
    const marketValue = position.quantity * quote.price;
    return [{ symbol, name: quote.name, quantity: position.quantity, averageEntry: position.averageEntry, lastPrice: quote.price, marketValue, unrealizedPnl: (quote.price - position.averageEntry) * position.quantity }];
  }).sort((first, second) => second.marketValue - first.marketValue);
}

export function getAccountMetrics(account: PaperAccountState, quotes: Quote[]): AccountMetrics {
  const positions = derivePositions(account, quotes);
  const investedValue = positions.reduce((sum, position) => sum + position.marketValue, 0);
  const unrealizedPnl = positions.reduce((sum, position) => sum + position.unrealizedPnl, 0);
  const equity = account.cash + investedValue;
  const totalPnl = equity - account.startingBalance;
  return { cash: account.cash, equity, investedValue, unrealizedPnl, realizedPnl: totalPnl - unrealizedPnl, totalPnl };
}

export function validatePaperTrade(account: PaperAccountState, quotes: Quote[], input: { symbol: string; side: TradeSide; quantity: number }) {
  const quote = quotes.find((candidate) => candidate.symbol === input.symbol);
  if (!quote) return "This instrument is not available in the training watchlist.";
  if (!Number.isFinite(input.quantity) || input.quantity <= 0) return "Enter a quantity greater than zero.";
  const notional = input.quantity * quote.price;
  if (input.side === "buy" && notional > account.cash + 0.000001) return "This simulated order exceeds the available paper cash balance.";
  if (input.side === "sell") {
    const position = derivePositions(account, quotes).find((candidate) => candidate.symbol === input.symbol);
    if (!position || input.quantity > position.quantity) return "You can only sell the quantity currently held in your paper portfolio.";
  }
  return null;
}

export function submitPaperOrder(account: PaperAccountState, quotes: Quote[], input: { symbol: string; side: TradeSide; quantity: number }): TradeResult {
  const validationError = validatePaperTrade(account, quotes, input);
  if (validationError) return { success: false, error: validationError };
  const quote = quotes.find((candidate) => candidate.symbol === input.symbol)!;
  const now = new Date().toISOString();
  const notional = input.quantity * quote.price;
  const order: PaperOrder = { id: `paper-${Date.now()}-${account.orders.length + 1}`, symbol: input.symbol, side: input.side, quantity: input.quantity, price: quote.price, notional, createdAt: now, status: "simulated" };
  const activity: ActivityItem = { id: `activity-${order.id}`, kind: "trade", title: `${input.side === "buy" ? "Bought" : "Sold"} ${input.quantity} ${input.symbol}`, detail: `Simulated ${input.side} at ${quote.price.toLocaleString("en-US")}. No live order was sent.`, createdAt: now };
  return { success: true, order, account: { ...account, cash: account.cash + (input.side === "buy" ? -notional : notional), orders: [...account.orders, order], activity: [activity, ...account.activity] } };
}
