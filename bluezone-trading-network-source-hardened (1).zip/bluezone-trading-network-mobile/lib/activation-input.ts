export function normalizeActivationTokenInput(value: string) {
  return value.replace(/\s+/g, "").toUpperCase();
}

export function activationClipboardNotice(value: string) {
  return normalizeActivationTokenInput(value)
    ? null
    : "Clipboard is empty. Copy the Bluezone token, then tap Paste token again.";
}
