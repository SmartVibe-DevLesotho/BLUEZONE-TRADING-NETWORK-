import { normalizeDeviceActivationResult, type DeviceActivationResult } from "@/lib/device-access-policy";
import { getPublicSupabaseConfig } from "@/lib/supabase";

type ActivationAction = "activate" | "status";

export async function requestDeviceLicense(action: ActivationAction, token: string, deviceId: string): Promise<DeviceActivationResult> {
  const config = getPublicSupabaseConfig();
  if (!config) {
    return {
      valid: false,
      expiresAt: null,
      message: "Activation service is not configured in this build.",
    };
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 12_000);
  try {
    const response = await fetch(`${config.url}/functions/v1/license-validate`, {
      method: "POST",
      headers: {
        apikey: config.publishableKey,
        Authorization: `Bearer ${config.publishableKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ action, token: token.trim(), deviceId }),
      signal: controller.signal,
    });
    const payload = await response.json().catch(() => null);
    return normalizeDeviceActivationResult(
      payload,
      response.ok
        ? "The activation service did not return a usable result."
        : "The activation service could not complete this request. Please try again.",
    );
  } catch (error) {
    const timedOut = error instanceof Error && error.name === "AbortError";
    return {
      valid: false,
      expiresAt: null,
      message: timedOut
        ? "Activation check timed out. Check the connection and try again."
        : "Activation service is unavailable. Check the connection and try again.",
    };
  } finally {
    clearTimeout(timeout);
  }
}
