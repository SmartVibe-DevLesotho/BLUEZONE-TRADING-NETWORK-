#!/usr/bin/env python3
"""Static APK metadata inspector. It never installs or executes the supplied package."""

from __future__ import annotations

import hashlib
import sys
import zipfile
from pathlib import Path

from androguard.core.apk import APK


def invoke(apk: APK, name: str):
    method = getattr(apk, name, None)
    if not callable(method):
        return None
    try:
        return method()
    except Exception:
        return None


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: inspect_apk_static.py <path-to-apk>", file=sys.stderr)
        return 2

    path = Path(sys.argv[1]).expanduser().resolve()
    if not path.is_file():
        print("APK file was not found.", file=sys.stderr)
        return 2

    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    apk = APK(str(path), raw=False)
    with zipfile.ZipFile(path) as archive:
        architectures = sorted(
            {
                name.split("/")[1]
                for name in archive.namelist()
                if name.startswith("lib/") and name.count("/") >= 2
            }
        )
        has_signing_block = b"APK Sig Block 42" in path.read_bytes()

    fields = {
        "sha256": digest,
        "package": invoke(apk, "get_package"),
        "version_name": invoke(apk, "get_androidversion_name"),
        "version_code": invoke(apk, "get_androidversion_code"),
        "min_sdk": invoke(apk, "get_min_sdk_version"),
        "target_sdk": invoke(apk, "get_target_sdk_version"),
        "application_label": invoke(apk, "get_app_name"),
        "main_activity": invoke(apk, "get_main_activity"),
        "architectures": ",".join(architectures) or None,
        "signature_v1": invoke(apk, "is_signed_v1"),
        "signature_v2": invoke(apk, "is_signed_v2"),
        "signature_v3": invoke(apk, "is_signed_v3"),
        "has_apk_signing_block": has_signing_block,
    }
    for key, value in fields.items():
        print(f"{key}={value}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
