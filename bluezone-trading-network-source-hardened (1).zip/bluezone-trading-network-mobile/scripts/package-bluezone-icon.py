from pathlib import Path

from PIL import Image

source = Path("/tmp/bluezone-app-icon.png")
targets = [
    Path("/home/ubuntu/bluezone-trading-network-mobile/assets/images/icon.png"),
    Path("/home/ubuntu/bluezone-trading-network-mobile/assets/images/splash-icon.png"),
    Path("/home/ubuntu/bluezone-trading-network-mobile/assets/images/favicon.png"),
    Path("/home/ubuntu/bluezone-trading-network-mobile/assets/images/android-icon-foreground.png"),
]

with Image.open(source) as image:
    image.convert("RGBA").save(targets[0], "PNG")
    for target in targets[1:]:
        image.convert("RGBA").save(target, "PNG")

print("\n".join(str(target) for target in targets))
