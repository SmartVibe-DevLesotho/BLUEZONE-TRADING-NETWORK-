const socket = new WebSocket("wss://api.derivws.com/trading/v1/options/ws/public");
const timeout = setTimeout(() => { console.error("Timed out waiting for public Deriv data"); socket.close(); process.exit(1); }, 25_000);
let verifiedSymbol;
let latestCandle;
let latestTick;

function finishIfVerified() {
  if (!verifiedSymbol || !latestCandle || !latestTick) return;
  console.log(JSON.stringify({ status: "public", symbol: verifiedSymbol, latestCandle, latestTick }));
  clearTimeout(timeout); socket.close();
}

socket.addEventListener("open", () => socket.send(JSON.stringify({ active_symbols: "brief", req_id: 1 })));
socket.addEventListener("message", (event) => {
  const payload = JSON.parse(String(event.data));
  if (payload.error) { console.error(JSON.stringify(payload.error)); clearTimeout(timeout); socket.close(); process.exit(1); }
  if (payload.msg_type === "active_symbols") {
    const symbol = payload.active_symbols.find((item) => item.market === "synthetic_index")?.underlying_symbol;
    if (!symbol) { console.error(JSON.stringify({ error: "No public synthetic index returned", response: payload, markets: [...new Set(payload.active_symbols.map((item) => item.market))], sample: payload.active_symbols.slice(0, 6) })); clearTimeout(timeout); socket.close(); process.exit(1); }
    verifiedSymbol = symbol;
    socket.send(JSON.stringify({ ticks_history: symbol, style: "candles", granularity: 14400, count: 10, end: "latest", req_id: 2 }));
    socket.send(JSON.stringify({ ticks: symbol, subscribe: 1, req_id: 3 }));
  }
  if (payload.msg_type === "candles") {
    const candles = Array.isArray(payload.candles) ? payload.candles : [];
    if (!candles.length) { console.error(JSON.stringify({ error: "No public candles returned", symbol: verifiedSymbol })); clearTimeout(timeout); socket.close(); process.exit(1); }
    latestCandle = candles.at(-1);
    finishIfVerified();
  }
  if (payload.msg_type === "tick") {
    const quote = Number(payload.tick?.quote);
    const epoch = Number(payload.tick?.epoch);
    if (!Number.isFinite(quote) || !Number.isFinite(epoch)) { console.error(JSON.stringify({ error: "Invalid public tick returned", symbol: verifiedSymbol })); clearTimeout(timeout); socket.close(); process.exit(1); }
    latestTick = { quote, epoch };
    finishIfVerified();
  }
});
socket.addEventListener("error", () => { console.error("Public Deriv WebSocket connection error"); clearTimeout(timeout); process.exit(1); });
