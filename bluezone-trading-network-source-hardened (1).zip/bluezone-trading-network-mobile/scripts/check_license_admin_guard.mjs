import "dotenv/config";

const url = process.env.EXPO_PUBLIC_SUPABASE_URL?.replace(/\/$/, "");
const key = process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

if (!url || !key) {
  throw new Error("Public Supabase configuration is not available for this diagnostic.");
}

const controller = new AbortController();
const timer = setTimeout(() => controller.abort(), 12_000);

try {
  const response = await fetch(`${url}/functions/v1/license-admin`, {
    method: "POST",
    headers: { apikey: key, "Content-Type": "application/json" },
    body: JSON.stringify({ action: "list" }),
    signal: controller.signal,
  });
  const body = await response.json().catch(() => ({}));
  console.log(JSON.stringify({
    httpStatus: response.status,
    ok: body?.ok ?? null,
    message: typeof body?.message === "string" ? body.message : null,
  }));
} finally {
  clearTimeout(timer);
}
