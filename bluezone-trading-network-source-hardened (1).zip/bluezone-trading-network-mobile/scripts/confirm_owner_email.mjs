import "dotenv/config";

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL?.replace(/\/$/, "");
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const ownerEmail = process.env.LICENSE_OWNER_EMAIL?.trim().toLowerCase();

if (!supabaseUrl || !serviceRoleKey || !ownerEmail) {
  throw new Error("Owner confirmation configuration is incomplete.");
}

const headers = {
  apikey: serviceRoleKey,
  Authorization: `Bearer ${serviceRoleKey}`,
  "Content-Type": "application/json",
};

const usersResponse = await fetch(`${supabaseUrl}/auth/v1/admin/users?page=1&per_page=1000`, { headers });
if (!usersResponse.ok) throw new Error(`Unable to inspect owner account (${usersResponse.status}).`);
const { users = [] } = await usersResponse.json();
const owner = users.find((user) => user.email?.toLowerCase() === ownerEmail);
if (!owner?.id) throw new Error("Configured owner account was not found.");

if (owner.email_confirmed_at) {
  console.log("Owner email is already confirmed; no change made.");
  process.exit(0);
}

const confirmationResponse = await fetch(`${supabaseUrl}/auth/v1/admin/users/${owner.id}`, {
  method: "PUT",
  headers,
  body: JSON.stringify({ email_confirm: true }),
});
if (!confirmationResponse.ok) throw new Error(`Owner email confirmation failed (${confirmationResponse.status}).`);
const confirmed = await confirmationResponse.json();
if (!confirmed?.user?.email_confirmed_at && !confirmed?.email_confirmed_at) throw new Error("Owner confirmation response did not include a confirmation timestamp.");

console.log("Configured owner email confirmed. No password, client token, or client account was changed.");
