import "dotenv/config";

const url = process.env.EXPO_PUBLIC_SUPABASE_URL?.replace(/\/$/, "");
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) throw new Error("Supabase diagnostics are not configured.");

const headers = { apikey: key, Authorization: `Bearer ${key}` };
const get = async (path) => {
  const response = await fetch(`${url}/rest/v1/${path}`, { headers });
  if (!response.ok) throw new Error(`Diagnostic query failed (${response.status}).`);
  return response.json();
};

const licenses = await get("licenses?select=id,label,active,expires_at,max_activations,activation_count,issued_at,revoked_at,issued_by&order=issued_at.desc&limit=100");
const activations = await get("license_device_activations?select=license_id,activated_at,last_checked_at,revoked_at&order=activated_at.desc&limit=200");
const ownerEmail = process.env.LICENSE_OWNER_EMAIL?.trim().toLowerCase();
const usersResponse = await fetch(`${url}/auth/v1/admin/users?per_page=1000`, { headers });
if (!usersResponse.ok) throw new Error(`Owner diagnostic failed (${usersResponse.status}).`);
const usersPayload = await usersResponse.json();
const users = usersPayload.users ?? [];
const owner = ownerEmail ? users.find((user) => String(user.email ?? "").toLowerCase() === ownerEmail) : null;
const activationCounts = new Map();
for (const activation of activations) activationCounts.set(activation.license_id, (activationCounts.get(activation.license_id) ?? 0) + 1);

console.table(licenses.map((license) => ({
  id: license.id.slice(0, 8),
  label: license.label ?? "(none)",
  active: license.active,
  revoked: Boolean(license.revoked_at),
  expiresAt: license.expires_at,
  maxDevices: license.max_activations,
  recordedActivations: license.activation_count,
  deviceRows: activationCounts.get(license.id) ?? 0,
  issuedAt: license.issued_at,
})));
console.table([{
  configuredOwnerFound: Boolean(owner),
  issuedTokens: licenses.length,
  ownerIssuedTokens: owner ? licenses.filter((license) => license.issued_by === owner.id).length : 0,
  tokensWithDifferentIssuer: owner ? licenses.filter((license) => license.issued_by !== owner.id).length : licenses.length,
}]);
console.log(`Reviewed ${licenses.length} license records and ${activations.length} device-activation records. Raw tokens and device hashes were not read.`);
