# Requirement Reconciliation

The active project will adopt the requirement document’s seven-area information architecture, developer credit, support links, education, session reference, broker directory, market catalog, paper trading, and cloud-readiness structure. The following capabilities have dependencies outside the mobile client and will remain clearly marked as pending rather than simulated as active.

| Requirement | Active implementation boundary |
|---|---|
| Free public forex, crypto, metals, index, and synthetic data | Public server/client providers are used only when a symbol and freshness state can be verified. Any unavailable instrument is labelled training-only or provider-pending. |
| Consensus signal engine | Present as a deterministic, educational paper-trading model. It does not represent a live recommendation or execute an order. |
| Supabase authentication and cloud storage | The validated client configuration is ready for account flows. Database access depends on the supplied schema and RLS policies being deployed. |
| License validation | The UI will call the supplied `license-validate` Edge Function only after it is deployed. Until then, it must show service-pending rather than falsely activating a license. |
| AI chatbot | A local educational assistant is available in the app. A Gemini/Edge Function response is provider-pending until the server-side function and its key are deployed; no key is embedded in the client. |
| MT5 bridge or robot automation | Disabled. Credential collection, storage, broker linking, and any real/demo order execution require a separately authorized server-side bridge and explicit end-user confirmation. |
| Broker directory | Presented as a research directory with external links and a note that broker terms, regulation, and availability must be confirmed with each broker. |

> Bluezone remains a paper-trading companion in this build. The app does not submit broker orders, deposit or withdraw funds, or store MT5 passwords.
