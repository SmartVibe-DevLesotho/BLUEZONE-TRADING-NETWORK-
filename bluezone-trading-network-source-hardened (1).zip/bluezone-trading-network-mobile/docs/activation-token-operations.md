# Bluezone Activation Token Operations

## Access Model

Bluezone requires one customer-facing step before opening live market research: **install the app and enter a Bluezone token issued by the owner**. The app generates a secure per-install identifier, stores the activation token in device-secure storage, and validates that pairing against the owner’s private Supabase project. Customers do not create, sign in to, or receive Supabase credentials.

| Role | Required action | Access result |
|---|---|---|
| Bluezone owner | Sign in with the configured owner Supabase email, then open **Owner sign-in — manage tokens**. | May issue, list, and revoke subscription tokens. |
| Subscriber | Install the app and enter the owner-issued `BZN-…` token. | Receives live-research access only while the device activation remains active and unexpired. |
| Expired subscriber | Request a new owner-issued token and activate the installed app again. | A new active token restores access. |
| Revoked subscriber | Cannot re-enter the research workspace with that token. | Must contact the owner for a replacement, if appropriate. |

## Owner Workflow

The owner console is authorized by the owner’s signed-in email on the server. It is not protected by a client-side role toggle. To issue a token, enter an optional customer label, a duration from 1 to 365 days, and a device limit from 1 to 100. The service creates a cryptographically random `BZN-…` token, stores only its SHA-256 hash, and shows the raw token once. Save and send that token through the owner’s chosen sales/support channel.

The owner may revoke a token from the same console. Revocation makes the token inactive and blocks it at the next activation-status check. The app does not process payments or token sales; those remain outside the app and under the owner’s business process.

## Subscriber Workflow

After installation, a subscriber selects **Client activation** from the Welcome screen. If a prior token is saved, select **Use another token** to clear only the client activation, then select **Paste token** or enter the owner-supplied value. Activation is bound to that device’s securely generated installation identifier. Tokens support a configured multi-device limit, but re-entering the same token on the same installation does not consume another activation. Android removes device-secure storage upon uninstall, so a reinstalled or replacement device requires the owner to issue or reset a token.

When the linked token expires or is revoked, the app sends the user back to activation instead of displaying cached live data, charts, or signals. A new token can be activated on the same account to renew access.

## Security Boundaries

> Bluezone activation gates access to live market research. It does not place orders, connect to a broker, hold client funds, or produce a guaranteed trading result.

Owner issuance requires a genuine Supabase user JWT and additionally verifies the configured owner email server-side. Customer validation uses the high-entropy owner-issued token plus a secure per-install identifier over HTTPS; it does not require a Supabase user session. Token hashes, device-activation hashes, expiry records, and revocation status reside in Supabase. The raw token is stored only in the installed app’s secure storage after activation and is never stored as plaintext in the database.

## Production Verification Checklist

Before sharing the APK, the owner should sign in with the configured owner account, issue one short-lived one-device token, and copy it before leaving the one-time token view. The owner should then use **Owner sign out — test client activation**, select **Client activation** from Welcome, choose **Use another token** if an old token exists, select **Paste token**, and activate the test token. The expected route is **Device activated** → risk disclosure → Markets.

For the denial check, the owner should return to the owner console, revoke that same test token, sign out again, choose **Client activation** → **Use another token** → **Paste token**, and retry the copied value. The expected result is the visible message **This activation token has been revoked** with no route to risk disclosure or Markets. Do not paste any live token into chat or screenshots.
