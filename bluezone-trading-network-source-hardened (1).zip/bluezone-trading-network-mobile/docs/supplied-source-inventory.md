# Supplied Bluezone Source Inventory

The supplied files represent three historical stages of the same product. The original Snack archive contains the initial paper-account and six-instrument phone test. `BlueZoneExpo.zip` is a monolithic Expo prototype with local gates and Supabase client setup. `bluezone-native-supabase-ready.tar.gz` is the most complete reference: an Expo Router workspace, Supabase schema, secure client bootstrap, and Edge Function sources.

| Module | Supplied state | Consolidation decision |
|---|---|---|
| Paper account and local order flow | Implemented across all sources | Keep active local-first paper engine as the dependable baseline. |
| Public live market data | The source Edge Function mixes public FX/crypto sources with generated fallbacks | Use the active server-side no-key quote adapter, which labels public, partial, and bundled states rather than generating price changes. |
| Market categories and instrument catalog | Source lists Forex, Metals, Crypto, Indices, and Deriv | Add browsing and category context. Only instruments supported by a verified public quote mapping appear as current provider quotes; unsupported catalog entries remain training-only. |
| Strategies, sessions, and education | Seed data and dedicated routes included | Integrate these as educational/training modules. They do not create trade advice or automated execution. |
| MT5/broker workflow | Schema and status screen exist; source itself states automatic execution is disabled | Preserve an explicit provider-pending status screen. Do not collect passwords, connect accounts, or submit orders. |
| Supabase Auth and cloud state | Source includes RLS schema, client setup, and Edge Functions | Add a safe client boundary with only URL and publishable key. Cloud operations remain opt-in and must respect the supplied RLS deployment. |
| Licenses, AI chat, and Edge Functions | Source contains server-side designs only | Document as deployment-dependent. Do not activate a licensing or AI workflow without the corresponding Supabase function deployment and authorization policy. |

## Deployment Boundary

The supplied SQL script creates Postgres/Supabase tables, RLS policies, triggers, and seed content. It cannot be applied to the active project’s managed MySQL database. The schema should therefore remain as a reviewed Supabase deployment artifact until the user confirms that it has been applied in their Supabase project. The app must not claim cloud synchronization, license validation, signal generation, or MT5 connection as active until their matching Edge Functions are deployed and verified.
