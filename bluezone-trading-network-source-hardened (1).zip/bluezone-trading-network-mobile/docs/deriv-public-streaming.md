# Deriv Public Streaming Integration

Bluezone requests **active symbols**, **ticks**, and **tick history** from Deriv’s current public market-data WebSocket endpoint, `wss://api.derivws.com/trading/v1/options/ws/public`, without account authentication. The integration uses those public requests only for display and charting. It does not issue proposals, purchases, sales, deposits, withdrawals, account, portfolio, or contract commands. [1] [2]

| Bluezone function | Public Deriv request | Availability handling |
|---|---|---|
| Synthetic symbol picker | `active_symbols: "brief"` | The picker displays only active provider symbols returned by Deriv. It derives the selectable identifier from the current `underlying_symbol` field, not a hard-coded legacy symbol. |
| Current synthetic price | `ticks: <provider symbol>` | A returned tick is shown as a public provider price with its timestamp. Connection failure produces a visible unavailable state. |
| Synthetic candles | `ticks_history` with `style: "candles"` and an allowed granularity | The chart uses provider OHLC candles only. A missing response never becomes a simulated candle series. |
| Stream continuation | `subscribe: 1` on permitted market-data calls | A source timestamp is shown for returned values. A disconnect or malformed response is labelled unavailable; it never becomes a simulated price or candle. |

The live verification path completed on 24 August 2026 with a provider-discovered synthetic symbol, non-empty H4 candles, and a finite public tick. The identifier is selected dynamically from `active_symbols`, so the app does not assume an outdated `R_10` symbol or an obsolete legacy WebSocket application ID. The user-created OAuth application is not used for this public market-data connection, and no OAuth code, access token, PAT, or account information is stored by the feature. [1] [2] [3] [4]

## References

[1]: https://developers.deriv.com/docs/data/active-symbols/ "Deriv Active Symbols"
[2]: https://developers.deriv.com/docs/data/ticks/ "Deriv Ticks Stream"
[3]: https://developers.deriv.com/docs/data/ticks-history/ "Deriv Ticks History"
[4]: https://developers.deriv.com/docs/intro/api-overview/ "Deriv API Overview"
