# MT5-Style Native Chart Design

The supplied reference establishes a **trading-terminal hierarchy** rather than a simple price graph: an instrument header, a two-sided quote strip, timeframe controls, a large candlestick canvas, a price scale, moving-average overlays, and a separate RSI panel. Bluezone will apply that hierarchy natively without copying the reference branding or enabling real order execution.

| Reference pattern | Bluezone implementation | Data boundary |
|---|---|---|
| SELL / quantity / BUY strip | Indicative public quote strip with bid/ask-style values and a paper-only quantity selector. | Shows public last price and a disclosed indicative spread; it cannot submit a broker order. |
| H4 / timeframe control | Native M1, M5, M15, H1, H4, D1 selection chips. | Public source interval is mapped where supported; unavailable intervals show no fabricated candle series. |
| Candlestick price chart | OHLC candle bodies and wicks rendered with native SVG, current-price line, and a right-hand price scale. | Uses public OHLC data from the verified history adapter. |
| Green/red averages | Short and long simple moving-average overlays. | Computed from the same displayed public closing series. |
| RSI lower panel | 14-period RSI with 30, 50, and 70 guide lines. | Computed locally from the same public close series; it is an indicator, not a trade instruction. |

The complete chart surface will show its source, timestamp, freshness, and an explicit statement that the price, indicators, and market-state labels are informational only. Any instrument without verified OHLC mapping—including a provider-pending synthetic index—shows the unavailable state rather than a simulated MT5 chart.
