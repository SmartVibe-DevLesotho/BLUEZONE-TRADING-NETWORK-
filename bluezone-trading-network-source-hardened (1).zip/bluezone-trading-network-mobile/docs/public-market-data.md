# Public Market Data Integration

Bluezone will use the public Yahoo Finance chart endpoint through its server process, with no client-side credential and no paid-provider configuration. The adapter must use a browser-style `User-Agent`, request each configured symbol individually, cache successful results briefly, and treat timeouts, malformed responses, or rate limits as an explicit unavailable state rather than silently fabricating live data.

| Bluezone instrument | Public symbol | Display treatment | Notes |
|---|---|---|---|
| XAUUSD | `GC=F` | Gold | The zero-cost source exposes Gold futures rather than a guaranteed spot-XAU/USD contract, so the quote label must disclose the provider symbol. |
| EURUSD | `EURUSD=X` | Euro / Dollar | Public currency quote. |
| GBPUSD | `GBPUSD=X` | Pound / Dollar | Public currency quote. |
| USDJPY | `JPY=X` | Dollar / Yen | Public currency quote convention used by the provider. |
| BTCUSD | `BTC-USD` | Bitcoin | Public cryptocurrency quote. |
| US30 | `^DJI` | Dow Jones | Public Dow Jones Industrial Average index quote. |

The mobile app will describe these as **public-provider quotes** and show the most recent successful server refresh time. It must not promise exchange-grade delivery, continuous streaming, or a guaranteed quote delay. Paper orders remain simulations and will use the last safely normalized quote available to the app.

## References

[1]: https://query1.finance.yahoo.com/v8/finance/chart/EURUSD%3DX?range=1d&interval=1m "Yahoo Finance public chart response for EUR/USD"
[2]: https://query1.finance.yahoo.com/v8/finance/chart/GC%3DF?range=1d&interval=1m "Yahoo Finance public chart response for Gold futures"
[3]: https://query1.finance.yahoo.com/v8/finance/chart/%5EDJI?range=1d&interval=1m "Yahoo Finance public chart response for Dow Jones"
