# Bluezone Live Signal Methodology

## Purpose and Boundary

Bluezone presents **live, explainable market research** from provider-returned prices and candle closes. It does not represent a signal as a guaranteed result, personalised financial advice, an instruction to trade, or a broker-executable order. Orders remain local paper-account actions only.

| Element | Current implementation | If unavailable or conflicting |
|---|---|---|
| Forex, metals, crypto, indices | Yahoo Finance public minute history, fetched server-side | No substitute quote or signal is shown. |
| Deriv synthetic indices | Deriv no-auth public WebSocket symbols, ticks, and candles | The workspace labels the source unavailable and shows no synthetic value. |
| Directional assessment | 5 versus 20 moving-average direction, five-period momentum, RSI 14 regime, and source freshness | The engine returns `WAIT` or `UNAVAILABLE`, not a directional result. |
| Reference invalidation | Lowest recent five closes for a long bias; highest recent five closes for a short bias | It is a method reference, not an order, stop-loss, or trade instruction. |

## Directional Logic

A long bias requires at least two of three inputs to agree: fast average above slow average, positive five-period momentum, and RSI 14 from 52 through 70. A short bias uses the inverse: fast average below slow average, negative five-period momentum, and RSI 14 from 30 through 48. Three aligned inputs are labelled **strong** at 85% method alignment; two aligned inputs are labelled **moderate** at 65%.

The engine intentionally returns `WAIT` when the inputs conflict, the RSI is extended above 70 or below 30, or source data is stale. It returns `UNAVAILABLE` when there are not enough complete provider-returned closes. This prevents a stale, incomplete, or overextended series from becoming a directional card.

> A percentage in Bluezone is **method-input alignment**, not a probability of profit or forecast confidence.

## Background Alert Readiness

The app now stores local watch preferences, presents real-time alert eligibility, and includes configuration for native notifications in a released build. The included Supabase migration prepares authenticated-user watch settings, device tokens, and de-duplicated alert-event records.

Closed-app delivery is deliberately not claimed active yet. It requires all of the following: a released Android/iOS build; an explicit notification permission from the user; production push credentials; secure storage of each user’s push token; and a persistent server-side monitor that evaluates fresh provider data, records a unique event, then sends a notification. `WAIT`, stale, unavailable, and conflicting signals remain ineligible.

## Operational Safeguards

The background monitor must use the same deterministic rules as the in-app engine, run server-side rather than on a closed mobile client, and de-duplicate events by symbol, direction, and source timestamp. It must never authenticate a broker, accept a Deriv or MT5 credential, submit a transaction, create a contract, or write a live trade.

## References

[1]: https://developers.deriv.com/docs/data/active-symbols/ "Deriv Active Symbols"
[2]: https://developers.deriv.com/docs/intro/api-overview/ "Deriv API Overview"
[3]: https://docs.expo.dev/versions/latest/sdk/notifications/ "Expo Notifications"
