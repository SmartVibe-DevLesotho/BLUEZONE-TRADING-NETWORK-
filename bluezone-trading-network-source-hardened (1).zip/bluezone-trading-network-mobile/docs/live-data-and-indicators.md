# Live Data and Market Indicators

Bluezone’s live-data upgrade uses public, no-key sources with a server-side cache and visible freshness state. The product describes its outputs as **market indicators**, not a personalised recommendation, prediction, or instruction to trade.

| Data need | Selected source | Bluezone treatment |
|---|---|---|
| Forex reference and historical rates | Frankfurter public API | Use as an open-source reference fallback for supported currency pairs; its documentation describes daily rates, so it must not be presented as tick data. |
| Forex, metals, crypto, and global index minute-history | Yahoo Finance public chart endpoint | Use as an indicative public quote/history source with short server cache, source label, timestamp, and unavailable fallback. |
| Crypto coverage | CoinGecko public/demo documentation reviewed; public capability remains rate-limited | Keep Yahoo Finance as the default unified adapter. A CoinGecko adapter can be enabled only within the published free limits. |
| Synthetic indices | Deriv public market-data API documented | Keep existing demo/training state until a provider-ready public-symbol adapter is separately verified. No account or contract calls. |

## Indicator Boundary

The signal engine will calculate an **explainable market-state label** from public price history: moving-average direction, recent momentum, and data freshness. It will display the underlying measurements, the calculated label, the source timestamp, and a statement that it is not financial advice or a broker instruction. No signal triggers order placement, account linking, deposit, withdrawal, or MT5 action.

## References

[1]: https://frankfurter.dev/ "Frankfurter free open-source exchange-rate API"
[2]: https://docs.coingecko.com/ "CoinGecko API documentation"
[3]: https://query1.finance.yahoo.com/v8/finance/chart/EURUSD%3DX?range=1d&interval=1m "Yahoo Finance public EUR/USD chart response"
[4]: https://developers.deriv.com/docs/workflows/ "Deriv public market-data workflow"
