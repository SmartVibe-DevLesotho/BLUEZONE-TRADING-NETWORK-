# Deriv Public Data Boundary

Bluezone may display **public Deriv market data** without a Deriv login by using the provider’s documented public WebSocket endpoint. The app will use this only for active-symbol discovery and tick display in the dedicated Deriv workspace. It will not request account balances, proposals, purchases, sales, deposits, withdrawals, or any other authenticated activity.

| Capability | Bluezone state | Boundary |
|---|---|---|
| Active synthetic-symbol list | Available through the unauthenticated public WebSocket flow | Display as provider data, with connection and freshness state. |
| Public ticks | Available for a selected provider symbol when the public stream responds | Treat as an indicative public stream and show reconnect/unavailable state. |
| Deriv account, demo, or real execution | Not activated | Requires a registered application, an authorized token/OAuth flow, and explicit product/legal review; intentionally not implemented. |
| Broker credentials | Not collected | The app has no password or token form and no credential storage path for brokers. |

## References

[1]: https://developers.deriv.com/docs/workflows/ "Deriv complete workflows: public WebSocket market-data flow"
[2]: https://developers.deriv.com/docs/data/active-symbols/ "Deriv active symbols: unauthenticated market-data endpoint"
[3]: https://developers.deriv.com/docs/intro/api-overview/ "Deriv API overview: public versus authenticated endpoints"
