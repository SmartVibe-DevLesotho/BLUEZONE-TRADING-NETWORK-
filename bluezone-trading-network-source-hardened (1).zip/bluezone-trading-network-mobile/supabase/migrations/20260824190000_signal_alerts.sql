create table if not exists public.signal_alert_watches (
  user_id uuid primary key references auth.users(id) on delete cascade,
  enabled boolean not null default false,
  min_alignment integer not null default 60 check (min_alignment in (40, 60, 80)),
  symbols text[] not null default array[]::text[],
  updated_at timestamptz not null default now()
);

create table if not exists public.push_devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  expo_push_token text not null unique,
  platform text not null check (platform in ('ios', 'android')),
  active boolean not null default true,
  updated_at timestamptz not null default now(),
  unique(user_id, expo_push_token)
);

create table if not exists public.signal_alert_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  dedupe_key text not null unique,
  symbol text not null,
  direction text not null check (direction in ('LONG_BIAS', 'SHORT_BIAS')),
  alignment_score integer not null check (alignment_score between 0 and 100),
  source_as_of timestamptz not null,
  delivery_status text not null default 'PENDING' check (delivery_status in ('PENDING', 'SENT', 'FAILED', 'SKIPPED')),
  created_at timestamptz not null default now()
);

alter table public.signal_alert_watches enable row level security;
alter table public.push_devices enable row level security;
alter table public.signal_alert_events enable row level security;

do $$ begin if not exists (select 1 from pg_policies where schemaname = 'public' and tablename = 'signal_alert_watches' and policyname = 'alert watches own row') then create policy "alert watches own row" on public.signal_alert_watches for all using (auth.uid() = user_id) with check (auth.uid() = user_id); end if; end $$;
do $$ begin if not exists (select 1 from pg_policies where schemaname = 'public' and tablename = 'push_devices' and policyname = 'push devices own row') then create policy "push devices own row" on public.push_devices for all using (auth.uid() = user_id) with check (auth.uid() = user_id); end if; end $$;
do $$ begin if not exists (select 1 from pg_policies where schemaname = 'public' and tablename = 'signal_alert_events' and policyname = 'alert events own row') then create policy "alert events own row" on public.signal_alert_events for select using (auth.uid() = user_id); end if; end $$;

create index if not exists signal_alert_events_user_created_idx on public.signal_alert_events(user_id, created_at desc);
create index if not exists signal_alert_events_pending_idx on public.signal_alert_events(delivery_status, created_at);
