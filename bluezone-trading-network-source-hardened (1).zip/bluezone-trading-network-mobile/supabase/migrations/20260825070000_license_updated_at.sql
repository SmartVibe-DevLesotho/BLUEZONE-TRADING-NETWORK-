-- The existing touch_updated_at trigger is attached to licenses. Ensure its target
-- column exists before owners update active/revoked token state.
alter table public.licenses
  add column if not exists updated_at timestamptz not null default now();

update public.licenses
set updated_at = coalesce(updated_at, issued_at, now())
where updated_at is null;
