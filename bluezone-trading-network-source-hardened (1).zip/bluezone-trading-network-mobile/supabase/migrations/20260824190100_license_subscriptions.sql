alter table public.licenses add column if not exists issued_by uuid references auth.users(id) on delete set null;
alter table public.licenses add column if not exists label text;
alter table public.licenses add column if not exists revoked_at timestamptz;
alter table public.licenses add column if not exists issued_at timestamptz not null default now();
alter table public.user_licenses add column if not exists last_validated_at timestamptz not null default now();

create index if not exists licenses_issued_by_idx on public.licenses(issued_by, issued_at desc);
create index if not exists user_licenses_user_idx on public.user_licenses(user_id, license_id);

create or replace function public.activate_bluezone_license(p_user_id uuid, p_token_hash text)
returns table(valid boolean, message text, license_expires_at timestamptz)
language plpgsql security definer set search_path = public as $$
declare
  v_license public.licenses%rowtype;
begin
  select * into v_license from public.licenses where token_hash = p_token_hash for update;
  if not found then
    return query select false, 'Invalid activation token.'::text, null::timestamptz;
    return;
  end if;
  if not v_license.active or v_license.revoked_at is not null then
    return query select false, 'This activation token has been revoked.'::text, v_license.expires_at;
    return;
  end if;
  if v_license.expires_at is not null and v_license.expires_at <= now() then
    return query select false, 'This activation token has expired.'::text, v_license.expires_at;
    return;
  end if;
  if exists (select 1 from public.user_licenses where user_id = p_user_id and license_id = v_license.id) then
    update public.user_licenses set last_validated_at = now() where user_id = p_user_id and license_id = v_license.id;
    return query select true, 'Activation is already active for this account.'::text, v_license.expires_at;
    return;
  end if;
  if v_license.activation_count >= v_license.max_activations then
    return query select false, 'This activation token has reached its account limit.'::text, v_license.expires_at;
    return;
  end if;
  insert into public.user_licenses(user_id, license_id, activated_at, last_validated_at) values (p_user_id, v_license.id, now(), now());
  update public.licenses set activation_count = activation_count + 1 where id = v_license.id;
  return query select true, 'Activation confirmed for this account.'::text, v_license.expires_at;
end;
$$;

revoke all on function public.activate_bluezone_license(uuid, text) from public, anon, authenticated;
