create table if not exists public.license_device_activations (
  id uuid primary key default gen_random_uuid(),
  license_id uuid not null references public.licenses(id) on delete cascade,
  device_hash text not null,
  activated_at timestamptz not null default now(),
  last_checked_at timestamptz not null default now(),
  revoked_at timestamptz,
  unique(license_id, device_hash)
);

create index if not exists license_device_activations_license_idx on public.license_device_activations(license_id, last_checked_at desc);
alter table public.license_device_activations enable row level security;

create or replace function public.activate_bluezone_license_device(p_token_hash text, p_device_hash text)
returns table(valid boolean, message text, license_expires_at timestamptz)
language plpgsql security definer set search_path = public as $$
declare
  v_license public.licenses%rowtype;
begin
  select * into v_license from public.licenses where token_hash = p_token_hash for update;
  if not found then
    return query select false, 'Invalid activation token.'::text, null::timestamptz;
    return;
  end if;
  if not v_license.active or v_license.revoked_at is not null then
    return query select false, 'This activation token has been revoked.'::text, v_license.expires_at;
    return;
  end if;
  if v_license.expires_at is not null and v_license.expires_at <= now() then
    return query select false, 'This activation token has expired.'::text, v_license.expires_at;
    return;
  end if;
  if exists (select 1 from public.license_device_activations where license_id = v_license.id and device_hash = p_device_hash and revoked_at is null) then
    update public.license_device_activations set last_checked_at = now() where license_id = v_license.id and device_hash = p_device_hash;
    return query select true, 'Device activation is active.'::text, v_license.expires_at;
    return;
  end if;
  if v_license.activation_count >= v_license.max_activations then
    return query select false, 'This activation token has reached its device limit.'::text, v_license.expires_at;
    return;
  end if;
  insert into public.license_device_activations(license_id, device_hash) values (v_license.id, p_device_hash);
  update public.licenses set activation_count = activation_count + 1 where id = v_license.id;
  return query select true, 'Device activation confirmed.'::text, v_license.expires_at;
end;
$$;

revoke all on function public.activate_bluezone_license_device(text, text) from public, anon, authenticated;
