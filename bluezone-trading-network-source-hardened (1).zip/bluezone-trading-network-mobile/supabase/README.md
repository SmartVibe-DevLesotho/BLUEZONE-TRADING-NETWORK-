# Bluezone Supabase Deployment

The migration at `migrations/20260824_bluezone_schema.sql` and the four Edge Functions are prepared from the user-supplied Bluezone package. They avoid random/demo market data: unavailable public sources return explicit **partial**, **unavailable**, or **provider-pending** states.

| Asset | Purpose | Required deployment configuration |
|---|---|---|
| `market-data` | Public quote adapter | No provider secret; uses public Yahoo Finance chart data. |
| `consensus-signals` | Explainable market-state calculations | No provider secret; public Yahoo Finance minute history. |
| `license-validate` | Token validation for a signed-in account | `SUPABASE_SERVICE_ROLE_KEY`; never expose this in the mobile client. |
| `ai-chat` | Optional educational assistant | `GEMINI_API_KEY` in the Edge Function environment; the mobile client never receives it. |

The remote deployment is **not yet run** because the provided Supabase management token failed validation. Once a valid personal access token is supplied, deployment should use the selected project reference, apply the migration, deploy all Edge Functions, set the two server-side secrets where appropriate, and then run authenticated smoke tests. Do not deploy an MT5 bridge or collect broker passwords as part of this package.
