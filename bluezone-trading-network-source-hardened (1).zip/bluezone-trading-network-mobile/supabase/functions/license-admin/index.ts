import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders } from "../_shared/cors.ts";
import { isUuid, sanitizeLicenseLabel } from "../_shared/license-guards.ts";

const hash = async (value: string) => Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value.trim())))).map((byte) => byte.toString(16).padStart(2, "0")).join("");
const rawToken = () => { const bytes = new Uint8Array(24); crypto.getRandomValues(bytes); return `BZN-${Array.from(bytes).map((byte) => byte.toString(16).padStart(2, "0")).join("").toUpperCase()}`; };

function timeBound<T>(request: Promise<T>, milliseconds = 10_000) {
  let timeout: number | undefined;
  return Promise.race([request, new Promise<T>((_, reject) => { timeout = setTimeout(() => reject(new Error("Owner request timed out.")), milliseconds); })]).finally(() => { if (timeout) clearTimeout(timeout); });
}

async function verifiedOwner(admin: ReturnType<typeof createClient>, authorization: string | null, ownerEmail: string) {
  const token = authorization?.replace(/^Bearer\s+/i, "") ?? "";
  if (!token) return null;
  const { data, error } = await timeBound(admin.auth.getUser(token));
  const user = data.user;
  if (error || !user || user.email?.trim().toLowerCase() !== ownerEmail) return null;
  return user;
}

Deno.serve(async (request) => {
  if (request.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (request.method !== "POST") return Response.json({ ok: false, message: "Method not allowed." }, { status: 405, headers: corsHeaders });

  const url = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const ownerEmail = Deno.env.get("LICENSE_OWNER_EMAIL")?.trim().toLowerCase();
  if (!url || !serviceKey || !ownerEmail) return Response.json({ ok: false, message: "Owner activation service is not configured." }, { status: 503, headers: corsHeaders });

  try {
    const admin = createClient(url, serviceKey, { auth: { autoRefreshToken: false, persistSession: false } });
    const owner = await verifiedOwner(admin, request.headers.get("Authorization"), ownerEmail);
    if (!owner) return Response.json({ ok: false, message: "Only the configured Bluezone owner may manage activation tokens." }, { status: 403, headers: corsHeaders });
    const body: unknown = await request.json().catch(() => null);
    if (!body || typeof body !== "object" || Array.isArray(body)) return Response.json({ ok: false, message: "A valid owner request is required." }, { status: 400, headers: corsHeaders });
    const input = body as Record<string, unknown>;

    if (input.action === "list") {
      const { data, error } = await timeBound(admin.from("licenses").select("id, label, active, expires_at, max_activations, activation_count, issued_at, revoked_at").eq("issued_by", owner.id).order("issued_at", { ascending: false }).limit(100));
      if (error) throw error;
      return Response.json({ ok: true, licenses: data ?? [] }, { headers: corsHeaders });
    }

    if (input.action === "revoke") {
      if (!isUuid(input.licenseId)) return Response.json({ ok: false, message: "A valid token record is required." }, { status: 400, headers: corsHeaders });
      const { data, error } = await timeBound(admin.from("licenses").update({ active: false, revoked_at: new Date().toISOString() }).eq("id", input.licenseId.trim()).eq("issued_by", owner.id).select("id").maybeSingle());
      if (error) throw error;
      return Response.json({ ok: Boolean(data), message: data ? "Token revoked." : "This token was not found in the owner account." }, { headers: corsHeaders });
    }

    if (input.action === "issue") {
      const durationDays = Number(input.durationDays);
      const maxActivations = Number(input.maxActivations);
      if (!Number.isInteger(durationDays) || durationDays < 1 || durationDays > 365 || !Number.isInteger(maxActivations) || maxActivations < 1 || maxActivations > 100) {
        return Response.json({ ok: false, message: "Choose a 1–365 day term and 1–100 device limit." }, { status: 400, headers: corsHeaders });
      }
      const token = rawToken();
      const expiresAt = new Date(Date.now() + durationDays * 86_400_000).toISOString();
      const { data, error } = await timeBound(admin.from("licenses").insert({ token_hash: await hash(token), active: true, expires_at: expiresAt, max_activations: maxActivations, activation_count: 0, issued_by: owner.id, label: sanitizeLicenseLabel(input.label) }).select("id, expires_at, max_activations").single());
      if (error) throw error;
      return Response.json({ ok: true, token, license: data, message: "Token issued. Show or copy it now; Bluezone stores only its hash." }, { headers: corsHeaders });
    }

    return Response.json({ ok: false, message: "Unsupported owner action." }, { status: 400, headers: corsHeaders });
  } catch {
    return Response.json({ ok: false, message: "Owner operation is temporarily unavailable. Please try again." }, { status: 503, headers: corsHeaders });
  }
});
