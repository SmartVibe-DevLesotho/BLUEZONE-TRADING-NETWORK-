const TOKEN_PATTERN = /^BZN-[A-Z0-9]{16,128}$/;
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export type ActivationAction = "activate" | "status";

export function isActivationAction(value: unknown): value is ActivationAction {
  return value === "activate" || value === "status";
}

export function isBluezoneToken(value: unknown): value is string {
  return typeof value === "string" && TOKEN_PATTERN.test(value.trim());
}

export function isDeviceIdentifier(value: unknown): value is string {
  return typeof value === "string" && UUID_PATTERN.test(value.trim());
}

export function isUuid(value: unknown): value is string {
  return typeof value === "string" && UUID_PATTERN.test(value.trim());
}

export function sanitizeLicenseLabel(value: unknown) {
  if (typeof value !== "string") return null;
  const normalized = value.replace(/[\u0000-\u001F\u007F]/g, " ").replace(/\s+/g, " ").trim().slice(0, 120);
  return normalized || null;
}
