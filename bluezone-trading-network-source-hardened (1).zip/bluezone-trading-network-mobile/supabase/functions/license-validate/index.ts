import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders } from "../_shared/cors.ts";
import { isActivationAction, isBluezoneToken, isDeviceIdentifier } from "../_shared/license-guards.ts";

const hash = async (value: string) => Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value.trim())))).map((byte) => byte.toString(16).padStart(2, "0")).join("");

function timeBound<T>(request: Promise<T>, label: string, milliseconds = 8_000) {
  let timeout: number | undefined;
  return Promise.race([
    request,
    new Promise<T>((_, reject) => { timeout = setTimeout(() => reject(new Error(`${label} timed out.`)), milliseconds); }),
  ]).finally(() => { if (timeout) clearTimeout(timeout); });
}

type License = { id: string; active: boolean; expires_at: string | null; revoked_at: string | null; activation_count: number; max_activations: number };

function validLicense(license: License | null) {
  if (!license) return "Invalid activation token.";
  if (!license.active || license.revoked_at) return "This activation token has been revoked.";
  if (license.expires_at && new Date(license.expires_at) <= new Date()) return "This activation token has expired.";
  return null;
}

async function loadLicense(admin: ReturnType<typeof createClient>, tokenHash: string) {
  const { data, error } = await timeBound(admin.from("licenses").select("id, active, expires_at, revoked_at, activation_count, max_activations").eq("token_hash", tokenHash).maybeSingle(), "License lookup");
  if (error) throw error;
  return data as License | null;
}

async function deviceActivation(admin: ReturnType<typeof createClient>, licenseId: string, deviceHash: string) {
  const { data, error } = await timeBound(admin.from("license_device_activations").select("id, revoked_at").eq("license_id", licenseId).eq("device_hash", deviceHash).maybeSingle(), "Device activation lookup");
  if (error) throw error;
  return data as { id: string; revoked_at: string | null } | null;
}

async function activeDeviceCount(admin: ReturnType<typeof createClient>, licenseId: string) {
  const { count, error } = await timeBound(admin.from("license_device_activations").select("id", { count: "exact", head: true }).eq("license_id", licenseId).is("revoked_at", null), "Device activation count");
  if (error) throw error;
  return count ?? 0;
}

Deno.serve(async (request) => {
  if (request.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (request.method !== "POST") return Response.json({ valid: false, message: "Method not allowed." }, { status: 405, headers: corsHeaders });

  const url = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !serviceKey) return Response.json({ valid: false, status: "provider-pending", message: "Secure activation service is not configured." }, { status: 503, headers: corsHeaders });

  try {
    const body: unknown = await request.json().catch(() => null);
    if (!body || typeof body !== "object" || Array.isArray(body)) return Response.json({ valid: false, message: "A valid activation request is required." }, { status: 400, headers: corsHeaders });
    const { action, token, deviceId } = body as Record<string, unknown>;
    if (!isActivationAction(action) || !isBluezoneToken(token) || !isDeviceIdentifier(deviceId)) {
      return Response.json({ valid: false, message: "A valid Bluezone token and device activation identifier are required." }, { status: 400, headers: corsHeaders });
    }

    const admin = createClient(url, serviceKey, { auth: { autoRefreshToken: false, persistSession: false } });
    const [tokenHash, deviceHash] = await Promise.all([hash(token), hash(deviceId)]);
    const license = await loadLicense(admin, tokenHash);
    const invalidMessage = validLicense(license);
    if (invalidMessage) return Response.json({ valid: false, expiresAt: license?.expires_at ?? null, message: invalidMessage }, { headers: corsHeaders });

    const existing = await deviceActivation(admin, license.id, deviceHash);
    if (action === "status") {
      const valid = Boolean(existing && !existing.revoked_at);
      return Response.json({ valid, expiresAt: license.expires_at, message: valid ? "Device activation is active." : "Enter a valid owner-issued token on this device." }, { headers: corsHeaders });
    }

    if (existing && !existing.revoked_at) {
      await timeBound(admin.from("license_device_activations").update({ last_checked_at: new Date().toISOString() }).eq("id", existing.id), "Activation refresh");
      return Response.json({ valid: true, expiresAt: license.expires_at, message: "Device activation is active." }, { headers: corsHeaders });
    }

    const deviceCount = await activeDeviceCount(admin, license.id);
    if (deviceCount >= license.max_activations) return Response.json({ valid: false, expiresAt: license.expires_at, message: "This activation token has reached its device limit." }, { headers: corsHeaders });

    const { error: activationError } = await timeBound(admin.from("license_device_activations").upsert({ license_id: license.id, device_hash: deviceHash, activated_at: new Date().toISOString(), last_checked_at: new Date().toISOString(), revoked_at: null }, { onConflict: "license_id,device_hash" }), "Device activation write");
    if (activationError) throw activationError;
    await timeBound(admin.from("licenses").update({ activation_count: deviceCount + 1 }).eq("id", license.id), "Activation count update").catch(() => undefined);

    return Response.json({ valid: true, expiresAt: license.expires_at, message: "Device activation confirmed." }, { headers: corsHeaders });
  } catch {
    return Response.json({ valid: false, message: "Activation service is temporarily unavailable. Please try again." }, { status: 503, headers: corsHeaders });
  }
});
