import { corsHeaders } from "../_shared/cors.ts";

const symbols: Record<string, string> = { EURUSD: "EURUSD=X", GBPUSD: "GBPUSD=X", USDJPY: "JPY=X", XAUUSD: "GC=F", XAGUSD: "SI=F", XPTUSD: "PL=F", BTCUSD: "BTC-USD", ETHUSD: "ETH-USD", LTCUSD: "LTC-USD", XRPUSD: "XRP-USD", LINKUSD: "LINK-USD", BNBUSD: "BNB-USD", SOLUSD: "SOL-USD", US30: "^DJI", US500: "^GSPC", US100: "^NDX", UK100: "^FTSE", GER40: "^GDAXI", JPN225: "^N225", AUS200: "^AXJO" };
const isFiniteNumber = (value: unknown): value is number => typeof value === "number" && Number.isFinite(value);

async function quote(symbol: string) {
  const providerSymbol = symbols[symbol]; if (!providerSymbol) return null;
  const response = await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(providerSymbol)}?range=1d&interval=1m`, { headers: { "User-Agent": "Mozilla/5.0 BluezoneMarketData/1.0", Accept: "application/json" } });
  if (!response.ok) return null;
  const body = await response.json(); const meta = body?.chart?.result?.[0]?.meta; const price = meta?.regularMarketPrice;
  if (!isFiniteNumber(price) || price <= 0) return null;
  return { symbol, providerSymbol, price, changePercent: isFiniteNumber(meta?.regularMarketChangePercent) ? meta.regularMarketChangePercent : null, asOf: isFiniteNumber(meta?.regularMarketTime) ? new Date(meta.regularMarketTime * 1000).toISOString() : new Date().toISOString(), origin: "public" as const };
}

Deno.serve(async (request) => {
  if (request.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const body = await request.json(); const requested = Array.isArray(body?.symbols) ? body.symbols.filter((value: unknown): value is string => typeof value === "string").slice(0, 30) : [];
    const results = await Promise.allSettled(requested.map(quote)); const quotes = results.flatMap((result) => result.status === "fulfilled" && result.value ? [result.value] : []); const unavailableSymbols = requested.filter((symbol: string) => !quotes.some((quote) => quote.symbol === symbol));
    return Response.json({ provider: "Yahoo Finance public chart", status: quotes.length === requested.length ? "public" : quotes.length ? "partial" : "unavailable", fetchedAt: new Date().toISOString(), quotes, unavailableSymbols }, { headers: corsHeaders });
  } catch (error) { return Response.json({ error: String(error), status: "unavailable", quotes: [] }, { status: 400, headers: corsHeaders }); }
});
