import { describe, expect, it, vi } from "vitest";
import { OWNER_SIGN_OUT_TARGET, signOutOwnerSession } from "../lib/owner-session-policy";

describe("owner session policy", () => {
  it("ends only the owner session and returns the public activation route", async () => {
    const signOut = vi.fn().mockResolvedValue({ error: null });

    await expect(signOutOwnerSession(signOut)).resolves.toBe(OWNER_SIGN_OUT_TARGET);
    expect(signOut).toHaveBeenCalledTimes(1);
  });

  it("does not redirect when Supabase reports a sign-out error", async () => {
    await expect(signOutOwnerSession(async () => ({ error: new Error("Session unavailable") }))).rejects.toThrow("Session unavailable");
  });
});
