import { describe, expect, it } from "vitest";
import { isPublicEntryRoute } from "../lib/access-route-policy";

describe("public entry route policy", () => {
  it("keeps welcome and client token switching reachable with a saved activation", () => {
    expect(isPublicEntryRoute("/welcome")).toBe(true);
    expect(isPublicEntryRoute("/client-access/")).toBe(true);
    expect(isPublicEntryRoute("/")).toBe(true);
  });

  it("does not treat protected research routes as public entry", () => {
    expect(isPublicEntryRoute("/(tabs)")).toBe(false);
    expect(isPublicEntryRoute("/risk-disclaimer")).toBe(false);
  });
});
