import { describe, expect, it } from "vitest";
import { deviceAccessMessage, normalizeDeviceActivationResult, shouldStoreActivation } from "../lib/device-access-policy";

describe("device activation access policy", () => {
  it("retains only a confirmed unexpired device activation", () => {
    expect(shouldStoreActivation({ valid: true, expiresAt: "2099-01-01T00:00:00.000Z", message: "ok" })).toBe(true);
  });

  it("does not retain rejected activations", () => {
    expect(shouldStoreActivation({ valid: false, expiresAt: null, message: "Invalid token." })).toBe(false);
  });

  it("explains expiry without requiring a client Supabase account", () => {
    expect(deviceAccessMessage({ valid: true, expiresAt: "2026-08-24T18:59:00.000Z", message: "ok" }, Date.parse("2026-08-24T19:00:00.000Z"))).toContain("expired");
  });

  it("preserves a server-provided revoked-token denial", () => {
    expect(normalizeDeviceActivationResult({ valid: false, expiresAt: null, message: "This activation token has been revoked." })).toEqual({
      valid: false,
      expiresAt: null,
      message: "This activation token has been revoked.",
    });
  });

  it("fails safely when an endpoint returns no usable JSON result", () => {
    expect(normalizeDeviceActivationResult(null, "Activation service unavailable.")).toEqual({
      valid: false,
      expiresAt: null,
      message: "Activation service unavailable.",
    });
  });
});
