import { describe, expect, it } from "vitest";
import { isActivationAction, isBluezoneToken, isDeviceIdentifier, isUuid, sanitizeLicenseLabel } from "../supabase/functions/_shared/license-guards";

describe("license request guards", () => {
  it("accepts only supported actions, well-formed Bluezone tokens, and per-install UUIDs", () => {
    expect(isActivationAction("activate")).toBe(true);
    expect(isActivationAction("delete")).toBe(false);
    expect(isBluezoneToken(`BZN-${"A".repeat(48)}`)).toBe(true);
    expect(isBluezoneToken("not-a-token")).toBe(false);
    expect(isDeviceIdentifier("3a02a4d9-4555-4356-91e5-16b22c7232ae")).toBe(true);
    expect(isDeviceIdentifier("device-1")).toBe(false);
  });

  it("validates UUID ownership references and strips control characters from labels", () => {
    expect(isUuid("3a02a4d9-4555-4356-91e5-16b22c7232ae")).toBe(true);
    expect(isUuid("not-a-uuid")).toBe(false);
    expect(sanitizeLicenseLabel("  Client\nOne\u0000 ")).toBe("Client One");
  });
});
