import { describe, expect, it } from "vitest";
import { MAX_CHART_SCALE, MIN_CHART_SCALE, chartPanLimit, clampChartPan, clampChartScale, defaultChartGestureState } from "../lib/chart-gesture-math";

describe("native chart gesture bounds", () => {
  it("keeps pinch zoom within the readable chart scale range", () => {
    expect(clampChartScale(0.5)).toBe(MIN_CHART_SCALE);
    expect(clampChartScale(1.8)).toBe(1.8);
    expect(clampChartScale(4)).toBe(MAX_CHART_SCALE);
  });

  it("keeps horizontal pan within the scale-dependent viewport limit", () => {
    expect(chartPanLimit(1)).toBe(0);
    expect(chartPanLimit(2)).toBe(130);
    expect(clampChartPan(400, 2)).toBe(130);
    expect(clampChartPan(-400, 2)).toBe(-130);
  });

  it("returns the unzoomed centered state for a double-tap reset", () => {
    expect(defaultChartGestureState()).toEqual({ scale: 1, translateX: 0 });
  });
});
