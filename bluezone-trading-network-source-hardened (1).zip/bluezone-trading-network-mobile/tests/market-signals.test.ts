import { describe, expect, it } from "vitest";
import { computeMarketSignal } from "../server/market-signals";

describe("explainable live-signal research", () => {
  it("reports a fresh long bias only when all method inputs align", () => {
    const closes = Array.from({ length: 30 }, (_, index) => 100 + index * 0.1 + (index % 3 === 0 ? -0.4 : 0));
    const signal = computeMarketSignal({ symbol: "EURUSD", name: "EURUSD", closes, asOf: new Date().toISOString() });
    expect(signal.direction).toBe("LONG_BIAS");
    expect(signal.strength).toBe("STRONG");
    expect(signal.inputs).toContain("RSI 14 regime");
    expect(signal.disclaimer).toContain("not personalised financial advice");
  });

  it("withholds a directional result when public history is insufficient", () => {
    const signal = computeMarketSignal({ symbol: "BTCUSD", name: "Bitcoin", closes: [1, 2, 3], asOf: new Date().toISOString() });
    expect(signal.direction).toBe("UNAVAILABLE");
    expect(signal.alignmentScore).toBe(0);
  });

  it("returns a no-trade state rather than a stale directional signal", () => {
    const signal = computeMarketSignal({ symbol: "USDJPY", name: "USD/JPY", closes: Array.from({ length: 25 }, (_, index) => 100 + index), asOf: new Date(Date.now() - 16 * 60_000).toISOString() });
    expect(signal.direction).toBe("WAIT");
    expect(signal.strength).toBe("NONE");
  });
});
