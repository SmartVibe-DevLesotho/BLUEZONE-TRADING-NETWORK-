import { describe, expect, it } from "vitest";
import { ownerAuthMessage, withOwnerAuthTimeout } from "../lib/owner-auth-feedback";

describe("owner authentication feedback", () => {
  it("explains email confirmation requirements without exposing credentials", () => {
    expect(ownerAuthMessage(new Error("Email not confirmed"))).toContain("Resend confirmation email");
  });

  it("maps invalid credentials to a clear owner recovery message", () => {
    expect(ownerAuthMessage(new Error("Invalid login credentials"))).toContain("password");
  });

  it("settles successful owner requests before the timeout", async () => {
    await expect(withOwnerAuthTimeout(Promise.resolve("ok"), 50)).resolves.toBe("ok");
  });
});
