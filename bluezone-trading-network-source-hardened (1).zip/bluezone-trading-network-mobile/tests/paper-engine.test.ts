import { describe, expect, it } from "vitest";

import { sampleQuotes } from "../lib/bluezone-data";
import { createInitialPaperAccount, derivePositions, getAccountMetrics, submitPaperOrder } from "../lib/paper-engine";

describe("paper trading engine", () => {
  it("creates a local simulated buy and updates cash and position state", () => {
    const account = createInitialPaperAccount();
    const result = submitPaperOrder(account, sampleQuotes, { symbol: "EURUSD", side: "buy", quantity: 100 });

    expect(result.success).toBe(true);
    if (!result.success) return;

    const quote = sampleQuotes.find((item) => item.symbol === "EURUSD")!;
    expect(result.account.cash).toBeCloseTo(10000 - quote.price * 100);
    expect(derivePositions(result.account, sampleQuotes)).toMatchObject([{ symbol: "EURUSD", quantity: 100 }]);
    expect(result.account.activity[0]?.kind).toBe("trade");
  });

  it("rejects an order that exceeds available simulated cash", () => {
    const result = submitPaperOrder(createInitialPaperAccount(), sampleQuotes, { symbol: "BTCUSD", side: "buy", quantity: 1 });
    expect(result).toEqual({ success: false, error: "This simulated order exceeds the available paper cash balance." });
  });

  it("does not allow a simulated sale without a matching paper position", () => {
    const result = submitPaperOrder(createInitialPaperAccount(), sampleQuotes, { symbol: "XAUUSD", side: "sell", quantity: 1 });
    expect(result).toEqual({ success: false, error: "You can only sell the quantity currently held in your paper portfolio." });
  });

  it("derives equity from paper cash and open positions", () => {
    const bought = submitPaperOrder(createInitialPaperAccount(), sampleQuotes, { symbol: "EURUSD", side: "buy", quantity: 100 });
    if (!bought.success) throw new Error("Expected the paper order to succeed.");

    const metrics = getAccountMetrics(bought.account, sampleQuotes);
    expect(metrics.equity).toBeCloseTo(10000);
    expect(metrics.investedValue).toBeCloseTo(108.42);
  });
});

