import { describe, expect, it } from "vitest";
import { activationClipboardNotice, normalizeActivationTokenInput } from "../lib/activation-input";

describe("activation token input", () => {
  it("normalizes clipboard token whitespace before activation", () => {
    expect(normalizeActivationTokenInput(" BZN-ab12\n cd34 ")).toBe("BZN-AB12CD34");
  });

  it("explains an empty clipboard without triggering activation", () => {
    expect(activationClipboardNotice("   ")).toContain("Clipboard is empty");
    expect(activationClipboardNotice("BZN-ABC")).toBeNull();
  });
});
