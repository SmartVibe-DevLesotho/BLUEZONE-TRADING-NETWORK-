import { describe, expect, it } from "vitest";

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
const managementToken = process.env.SUPABASE_ACCESS_TOKEN;

describe("Supabase client credentials", () => {
  it("can read the public Auth settings endpoint with the configured publishable key", async () => {
    expect(supabaseUrl, "EXPO_PUBLIC_SUPABASE_URL must be configured").toBeTruthy();
    expect(supabaseKey, "EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY must be configured").toBeTruthy();

    const response = await fetch(`${supabaseUrl!.replace(/\/$/, "")}/auth/v1/settings`, {
      headers: { apikey: supabaseKey! },
      signal: AbortSignal.timeout(10_000),
    });

    expect(response.status, await response.text()).toBe(200);
  });

  it("can access the Supabase management project list with the supplied deployment credential", async () => {
    expect(managementToken, "SUPABASE_ACCESS_TOKEN must be configured for deployment").toBeTruthy();
    const response = await fetch("https://api.supabase.com/v1/projects", {
      headers: { Authorization: `Bearer ${managementToken}` },
      signal: AbortSignal.timeout(10_000),
    });
    expect(response.status, await response.text()).toBe(200);
  });
});
