import { describe, expect, it } from "vitest";
import { activationMessage, hasActiveLicense } from "../lib/license-access";

describe("activation-token access policy", () => {
  const now = Date.parse("2026-08-24T19:00:00.000Z");

  it("permits an active unexpired owner-issued activation", () => {
    expect(hasActiveLicense([{ active: true, expiresAt: "2026-09-24T19:00:00.000Z" }], now)).toBe(true);
  });

  it("denies expired and revoked activations", () => {
    expect(hasActiveLicense([{ active: true, expiresAt: "2026-08-24T18:59:00.000Z" }], now)).toBe(false);
    expect(hasActiveLicense([{ active: true, expiresAt: null, revokedAt: "2026-08-20T00:00:00.000Z" }], now)).toBe(false);
  });

  it("gives a renewal-specific expiry message", () => {
    expect(activationMessage({ active: true, expiresAt: "2026-08-24T18:59:00.000Z" }, now)).toContain("expired");
  });
});
