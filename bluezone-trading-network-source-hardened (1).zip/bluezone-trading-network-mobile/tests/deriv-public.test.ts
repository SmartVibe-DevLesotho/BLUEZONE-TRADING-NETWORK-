import { describe, expect, it } from "vitest";
import { derivGranularity, derivIndicators, normalizeDerivCandles, normalizeDerivSymbols } from "../lib/deriv-public";

describe("Deriv public data normalization", () => {
  it("keeps only provider-confirmed synthetic symbols from the current public endpoint", () => {
    expect(normalizeDerivSymbols([{ underlying_symbol: "1HZ10V", underlying_symbol_name: "Volatility 10 (1s) Index", market: "synthetic_index", submarket: "random_index" }, { underlying_symbol: "frxEURUSD", underlying_symbol_name: "EUR/USD", market: "forex" }])).toEqual([{ symbol: "1HZ10V", displayName: "Volatility 10 (1s) Index", market: "synthetic_index", submarket: "random index" }]);
  });
  it("normalizes only complete Deriv OHLC candles", () => {
    const candles = normalizeDerivCandles([{ epoch: 1, open: "10", high: "12", low: "9", close: "11" }, { epoch: 2, open: 1, high: null, low: 0, close: 1 }]);
    expect(candles).toHaveLength(1); expect(candles[0].close).toBe(11); expect(derivGranularity("H4")).toBe(14400);
  });
  it("derives chart indicators only from confirmed provider candle closes", () => {
    const candles = Array.from({ length: 20 }, (_, index) => ({ timestamp: new Date(index * 1000).toISOString(), open: index + 1, high: index + 2, low: index, close: index + 1 }));
    const indicators = derivIndicators(candles); expect(indicators.sma20.at(-1)).toBe(10.5); expect(indicators.rsi14[14]).toBe(100);
  });
});
