import { describe, expect, it } from "vitest";

import { normalizeYahooChart, PUBLIC_INSTRUMENTS } from "../server/market-data";

const eurUsd = { symbol: "EURUSD" as const, name: "Euro / Dollar", assetClass: "FX" as const, providerSymbol: "EURUSD=X" };

describe("public market data normalization", () => {
  it("maps the supplied forex, metal, crypto, and index catalog to no-key public symbols while keeping Deriv separate", () => {
    const symbols = new Set(PUBLIC_INSTRUMENTS.map((instrument) => instrument.symbol));
    for (const symbol of ["EURUSD", "GBPUSD", "USDJPY", "XAUUSD", "XAGUSD", "BTCUSD", "ETHUSD", "US30", "US500", "GER40"]) expect(symbols.has(symbol)).toBe(true);
    expect(symbols.has("V10")).toBe(false);
    expect(PUBLIC_INSTRUMENTS.every((instrument) => instrument.providerSymbol.length > 0)).toBe(true);
  });
  it("normalizes a valid public chart payload with the provider market time", () => {
    const quote = normalizeYahooChart(eurUsd, {
      chart: { result: [{ meta: { regularMarketPrice: 1.1671, regularMarketChangePercent: -0.06, regularMarketTime: 1_700_000_000 } }] },
    }, "2026-08-24T12:00:00.000Z");

    expect(quote).toMatchObject({ symbol: "EURUSD", price: 1.1671, changePercent: -0.06, providerSymbol: "EURUSD=X", origin: "public" });
    expect(quote?.asOf).toBe("2023-11-14T22:13:20.000Z");
  });

  it("calculates a percentage change when the public response omits it", () => {
    const quote = normalizeYahooChart(eurUsd, {
      chart: { result: [{ meta: { regularMarketPrice: 1.2, chartPreviousClose: 1.1 } }] },
    });

    expect(quote?.changePercent).toBeCloseTo(9.0909, 3);
  });

  it("rejects a malformed or empty public response so the client can retain its safe fallback", () => {
    expect(normalizeYahooChart(eurUsd, { chart: { result: [] } })).toBeNull();
    expect(normalizeYahooChart(eurUsd, { chart: { result: [{ meta: { regularMarketPrice: 0 } }] } })).toBeNull();
  });
});
