import { describe, expect, it } from "vitest";

describe("activation-token owner configuration", () => {
  it("loads a valid server-side owner identity without requiring a Supabase administrator token in the app", () => {
    const ownerEmail = process.env.LICENSE_OWNER_EMAIL;
    expect(ownerEmail).toMatch(/^[^\s@]+@[^\s@]+\.[^\s@]+$/);
    expect(ownerEmail?.toLowerCase()).toBe("smartvibeslesotho@gmail.com");
  });
});
