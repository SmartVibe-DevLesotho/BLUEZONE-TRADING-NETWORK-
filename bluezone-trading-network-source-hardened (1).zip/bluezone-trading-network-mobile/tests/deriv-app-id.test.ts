import { describe, expect, it } from "vitest";

const DERIV_PUBLIC_MARKET_URL = "wss://api.derivws.com/trading/v1/options/ws/public";

function fetchPublicActiveSymbols() {
  return new Promise<unknown[]>((resolve, reject) => {
    const socket = new WebSocket(DERIV_PUBLIC_MARKET_URL);
    const timeout = setTimeout(() => { socket.close(); reject(new Error("Timed out waiting for Deriv public active symbols")); }, 20_000);
    socket.addEventListener("open", () => socket.send(JSON.stringify({ active_symbols: "brief", req_id: 1 })));
    socket.addEventListener("message", (event) => { try { const payload = JSON.parse(String(event.data)) as { error?: { message?: string }; msg_type?: string; active_symbols?: unknown[] }; if (payload.error) throw new Error(payload.error.message ?? "Deriv returned an unknown error"); if (payload.msg_type === "active_symbols") { clearTimeout(timeout); socket.close(); resolve(payload.active_symbols ?? []); } } catch (error) { clearTimeout(timeout); socket.close(); reject(error); } });
    socket.addEventListener("error", () => { clearTimeout(timeout); reject(new Error("Deriv public market-data WebSocket connection failed")); });
  });
}

describe("Deriv public market-data connection", () => {
  it("returns public active symbols without using an account credential", async () => {
    const symbols = await fetchPublicActiveSymbols();
    expect(symbols.length).toBeGreaterThan(0);
  }, 30_000);
});
