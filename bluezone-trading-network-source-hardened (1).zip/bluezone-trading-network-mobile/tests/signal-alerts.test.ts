import { describe, expect, it } from "vitest";
import { selectAlertEligibleSignals, toSignalAlertEvent } from "../lib/signal-alerts";

describe("signal alert eligibility", () => {
  const signals = [
    { symbol: "EURUSD", direction: "LONG_BIAS" as const, strength: "STRONG" as const, alignmentScore: 85, freshness: "fresh" as const, asOf: "2026-08-24T18:00:00.000Z", rationale: ["Three inputs agree."] },
    { symbol: "BTCUSD", direction: "WAIT" as const, strength: "NONE" as const, alignmentScore: 0, freshness: "fresh" as const, asOf: "2026-08-24T18:00:00.000Z", rationale: ["No-trade state."] },
    { symbol: "XAUUSD", direction: "SHORT_BIAS" as const, strength: "MODERATE" as const, alignmentScore: 65, freshness: "stale" as const, asOf: "2026-08-24T17:00:00.000Z", rationale: ["Stale source."] },
  ];

  it("allows only fresh watched directional research above the configured alignment threshold", () => {
    const eligible = selectAlertEligibleSignals({ signals, watchedSymbols: ["EURUSD", "BTCUSD", "XAUUSD"], minAlignment: 60, enabled: true });
    expect(eligible).toHaveLength(1);
    expect(eligible[0]).toMatchObject({ symbol: "EURUSD", direction: "LONG_BIAS", strength: "STRONG", alignmentScore: 85 });
  });

  it("withholds every event when monitoring is disabled", () => {
    expect(selectAlertEligibleSignals({ signals, watchedSymbols: ["EURUSD"], minAlignment: 60, enabled: false })).toEqual([]);
  });

  it("creates a deterministic dedupe key for an eligible event", () => {
    const eligible = selectAlertEligibleSignals({ signals, watchedSymbols: ["EURUSD"], minAlignment: 60, enabled: true });
    const event = toSignalAlertEvent(eligible[0]!);
    expect(event.dedupeKey).toBe("EURUSD:LONG_BIAS:2026-08-24T18:00:00.000Z");
    expect(event.body).toContain("Open Bluezone");
  });
});
