import { describe, expect, it } from "vitest";
import { DEVELOPER, educationalReply, publicSupportUrl, trainingPrice } from "../lib/bluezone-core";

describe("Bluezone workspace safety and support helpers", () => {
  it("creates a prefilled support URL using the credited developer contact", () => {
    expect(DEVELOPER.email).toBe("smartvibeslesotho@gmail.com");
    expect(publicSupportUrl("license")).toContain("26662649248");
    expect(publicSupportUrl("license")).toContain("license");
  });

  it("keeps the local educational assistant non-executing", () => {
    expect(educationalReply("What is the robot doing?")).toContain("does not connect to MT5");
    expect(trainingPrice("V10")).toBeGreaterThan(0);
  });
});
