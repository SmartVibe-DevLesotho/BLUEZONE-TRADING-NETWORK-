import { describe, expect, it } from "vitest";
import { normalizeHistory, rsi, simpleMovingAverage } from "../server/market-history";

describe("public chart history normalization", () => {
  it("keeps only finite public close points and never creates a synthetic series", () => {
    const result = normalizeHistory({ symbol: "EURUSD", name: "Euro / Dollar", timeframe: "M1", timestamps: [1, 2, 3, 4, 5, 6], opens: [1.1, null, 1.11, 1.12, 1.13, 1.14], highs: [1.1, null, 1.11, 1.12, 1.13, 1.14], lows: [1.1, null, 1.11, 1.12, 1.13, 1.14], closes: [1.1, null, 1.11, 1.12, 1.13, 1.14], marketTime: 6, fetchedAt: "2026-08-24T00:00:00.000Z" });
    expect(result.status).toBe("public");
    expect(result.candles).toHaveLength(5);
  });

  it("reports unavailable when fewer than five public points exist", () => {
    const result = normalizeHistory({ symbol: "XAUUSD", name: "Gold", timeframe: "M1", timestamps: [1, 2], opens: [1, null], highs: [1, null], lows: [1, null], closes: [1, null], fetchedAt: "2026-08-24T00:00:00.000Z" });
    expect(result.status).toBe("unavailable");
    expect(result.candles).toHaveLength(1);
  });

  it("computes indicator-ready averages and RSI from the displayed closing series", () => {
    expect(simpleMovingAverage([1, 2, 3, 4, 5], 3)).toEqual([null, null, 2, 3, 4]);
    const values = Array.from({ length: 18 }, (_, index) => index + 1); const output = rsi(values);
    expect(output[13]).toBeNull(); expect(output[14]).toBe(100);
  });
});
