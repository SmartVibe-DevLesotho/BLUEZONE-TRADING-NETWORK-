import { describe, expect, it } from "vitest";

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL?.replace(/\/$/, "");
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const geminiKey = process.env.GEMINI_API_KEY;
const ownerEmail = process.env.LICENSE_OWNER_EMAIL?.toLowerCase();

describe("server-side provider credentials", () => {
  it("authorizes a read-only Supabase REST probe with the service-role key", async () => {
    expect(supabaseUrl).toBeTruthy(); expect(serviceRoleKey).toBeTruthy();
    const response = await fetch(`${supabaseUrl}/rest/v1/user_preferences?select=user_id&limit=1`, { headers: { apikey: serviceRoleKey!, Authorization: `Bearer ${serviceRoleKey!}` } });
    expect(response.status).toBe(200);
  }, 20_000);

  it("finds the configured owner account and exposes confirmation as a recoverable state without reading any password", async () => {
    expect(supabaseUrl).toBeTruthy(); expect(serviceRoleKey).toBeTruthy(); expect(ownerEmail).toBeTruthy();
    const response = await fetch(`${supabaseUrl}/auth/v1/admin/users?page=1&per_page=1000`, { headers: { apikey: serviceRoleKey!, Authorization: `Bearer ${serviceRoleKey!}` } });
    expect(response.status).toBe(200);
    const payload = await response.json() as { users?: Array<{ email?: string; email_confirmed_at?: string | null }> };
    const owner = payload.users?.find((user) => user.email?.toLowerCase() === ownerEmail);
    expect(owner).toBeTruthy();
    expect(owner?.email_confirmed_at === null || typeof owner?.email_confirmed_at === "string").toBe(true);
  }, 20_000);

  it("authorizes a lightweight Gemini model-list probe without generating content", async () => {
    expect(geminiKey).toBeTruthy();
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(geminiKey!)}`);
    expect(response.status).toBe(200);
    const payload = await response.json() as { models?: unknown[] };
    expect(Array.isArray(payload.models)).toBe(true);
  }, 20_000);
});
