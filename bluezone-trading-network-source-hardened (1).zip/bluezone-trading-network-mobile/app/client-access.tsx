import { useEffect, useState } from "react";
import { ActivityIndicator, Alert, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { clearActivationToken, getActivationToken } from "@/lib/device-activation";
import { withRequestTimeout } from "@/lib/owner-auth-feedback";

export default function ClientAccessScreen() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [hasSavedToken, setHasSavedToken] = useState(false);
  const [switching, setSwitching] = useState(false);

  useEffect(() => {
    let active = true;
    getActivationToken()
      .then((token) => { if (active) setHasSavedToken(Boolean(token)); })
      .catch(() => { if (active) setHasSavedToken(false); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  const useAnotherToken = async () => {
    setSwitching(true);
    try {
      await withRequestTimeout(clearActivationToken(), "Clearing the previous client token");
      router.replace("/license" as never);
    } catch (error) {
      Alert.alert("Token switch unavailable", error instanceof Error ? error.message : "The old client token could not be cleared. Please try again.");
    } finally {
      setSwitching(false);
    }
  };

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]}>
      <ScrollView contentContainerStyle={styles.content}>
        <Pressable onPress={() => router.replace("/welcome" as never)}><Text style={styles.back}>‹ Back to welcome</Text></Pressable>
        <Text style={styles.eyebrow}>CLIENT ACCESS</Text>
        <Text style={styles.title}>Use your Bluezone token</Text>
        <Text style={styles.intro}>Choose a new, replacement, or existing client activation. This page is separate from the owner console.</Text>

        {loading ? <View style={styles.loading}><ActivityIndicator color="#2563EB" /><Text style={styles.loadingText}>Checking this device…</Text></View> : <>
          {hasSavedToken ? <View style={styles.savedCard}>
            <Text style={styles.savedTitle}>A client token is already saved</Text>
            <Text style={styles.savedText}>To test a new or revoked token, first choose Use another token. This removes only the saved client token; it does not affect the owner account or issued tokens.</Text>
            <Pressable onPress={() => router.replace("/risk-disclaimer" as never)} style={({ pressed }) => [styles.primary, pressed && styles.pressed]}><Text style={styles.primaryText}>Open with saved token</Text></Pressable>
          </View> : <View style={styles.emptyCard}><Text style={styles.savedTitle}>No client token saved</Text><Text style={styles.savedText}>Enter the Bluezone token supplied by the owner to activate this device.</Text></View>}

          <Pressable disabled={switching} onPress={useAnotherToken} style={({ pressed }) => [styles.switchButton, switching && styles.disabled, pressed && styles.pressed]}>
            <Text style={styles.switchText}>{switching ? "Preparing token entry…" : hasSavedToken ? "Use another token" : "Enter activation token"}</Text>
          </Pressable>
        </>}
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { flexGrow: 1, justifyContent: "center", padding: 22 },
  back: { color: "#2563EB", fontSize: 14, fontWeight: "900" },
  eyebrow: { color: "#2563EB", fontSize: 11, fontWeight: "900", letterSpacing: 1.2, marginTop: 28 },
  title: { color: "#0B1220", fontSize: 32, fontWeight: "900", marginTop: 5 },
  intro: { color: "#64748B", fontSize: 13, lineHeight: 19, marginTop: 8 },
  loading: { alignItems: "center", backgroundColor: "#F8FAFC", borderRadius: 16, marginTop: 24, padding: 22 },
  loadingText: { color: "#64748B", fontSize: 12, fontWeight: "800", marginTop: 10 },
  savedCard: { backgroundColor: "#EFF6FF", borderColor: "#93C5FD", borderRadius: 16, borderWidth: 1, marginTop: 24, padding: 16 },
  emptyCard: { backgroundColor: "#F8FAFC", borderRadius: 16, marginTop: 24, padding: 16 },
  savedTitle: { color: "#0B1220", fontSize: 15, fontWeight: "900" },
  savedText: { color: "#475569", fontSize: 12, lineHeight: 18, marginTop: 5 },
  primary: { alignItems: "center", backgroundColor: "#2563EB", borderRadius: 12, justifyContent: "center", marginTop: 16, minHeight: 48 },
  primaryText: { color: "#FFFFFF", fontSize: 13, fontWeight: "900" },
  switchButton: { alignItems: "center", borderColor: "#2563EB", borderRadius: 12, borderWidth: 1, justifyContent: "center", marginTop: 13, minHeight: 48 },
  switchText: { color: "#1D4ED8", fontSize: 13, fontWeight: "900" },
  disabled: { opacity: 0.55 }, pressed: { opacity: 0.72 },
});
