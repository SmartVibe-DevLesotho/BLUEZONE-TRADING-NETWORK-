import { ScrollView, StyleSheet, Text, View } from "react-native";
import { WorkspaceScreen, workspaceStyles } from "@/components/bluezone/workspace-screen";
import { getSupabaseReadiness } from "@/lib/supabase";
import { usePaperAccount } from "@/lib/paper-account-context";

export default function IntegrationStatusScreen() {
  const readiness = getSupabaseReadiness(); const { quoteFeed } = usePaperAccount();
  return <WorkspaceScreen eyebrow="INTEGRATION BOUNDARY" title="Cloud & broker"><ScrollView showsVerticalScrollIndicator={false}><View style={workspaceStyles.card}><Text style={workspaceStyles.label}>PUBLIC MARKET DATA</Text><Text style={[workspaceStyles.cardTitle, styles.title]}>{quoteFeed.status === "public" ? "Public quote feed active" : "Fallback state active"}</Text><Text style={workspaceStyles.copy}>{quoteFeed.provider}. The app labels public, partial, unavailable, and bundled states instead of claiming exchange-grade delivery.</Text></View><View style={workspaceStyles.card}><Text style={workspaceStyles.label}>SUPABASE CLIENT</Text><Text style={[workspaceStyles.cardTitle, styles.title]}>{readiness.configured ? "Client configured" : "Client not configured"}</Text><Text style={workspaceStyles.copy}>{readiness.database}. {readiness.functions}</Text></View><View style={workspaceStyles.card}><Text style={workspaceStyles.label}>BROKER / MT5</Text><Text style={[workspaceStyles.cardTitle, styles.title]}>Provider-pending</Text><Text style={workspaceStyles.copy}>No account credentials are collected or stored, no broker connection is established, and Bluezone cannot route, copy, or automate trades. The current paper account remains local and simulated.</Text></View></ScrollView></WorkspaceScreen>;
}
const styles = StyleSheet.create({ title: { marginTop: 5 } });
