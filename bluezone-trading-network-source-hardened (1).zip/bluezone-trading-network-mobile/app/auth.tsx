import { useState } from "react";
import { Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { supabase } from "@/lib/supabase";
import { ownerAuthMessage, withOwnerAuthTimeout } from "@/lib/owner-auth-feedback";

export default function AuthScreen() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const normalizedEmail = email.trim().toLowerCase();

  const submit = async () => {
    if (!supabase) {
      Alert.alert("Owner sign-in unavailable", "The secure owner configuration is not available in this build.");
      return;
    }
    if (!normalizedEmail.includes("@") || password.length < 6) {
      Alert.alert("Check your details", "Enter the authorised owner email and password.");
      return;
    }
    setLoading(true);
    try {
      const result = await withOwnerAuthTimeout(supabase.auth.signInWithPassword({ email: normalizedEmail, password }));
      if (result.error) {
        Alert.alert("Owner sign-in unavailable", ownerAuthMessage(result.error));
        return;
      }
      router.replace("/license-admin" as never);
    } catch (error) {
      Alert.alert("Owner sign-in unavailable", ownerAuthMessage(error));
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]}>
      <ScrollView contentContainerStyle={styles.content}>
        <Pressable onPress={() => router.replace("/welcome" as never)}><Text style={styles.back}>‹ Back to welcome</Text></Pressable>
        <Text style={styles.eyebrow}>RESTRICTED OWNER ACCESS</Text>
        <Text style={styles.title}>Owner sign in</Text>
        <Text style={styles.intro}>Only the authorised Bluezone owner can issue, renew, and revoke customer tokens. Clients should return to Welcome and choose Client activation.</Text>
        <TextInput value={email} onChangeText={setEmail} autoCapitalize="none" autoComplete="email" keyboardType="email-address" placeholder="Authorised owner email" placeholderTextColor="#94A3B8" style={styles.input} />
        <TextInput value={password} onChangeText={setPassword} autoCapitalize="none" autoComplete="password" secureTextEntry placeholder="Owner password" placeholderTextColor="#94A3B8" style={styles.input} />
        <Pressable disabled={loading} onPress={submit} style={({ pressed }) => [styles.primary, loading && styles.disabled, pressed && styles.pressed]}><Text style={styles.primaryText}>{loading ? "Signing in…" : "Sign in as owner"}</Text></Pressable>
        <View style={styles.note}><Text style={styles.noteTitle}>Client privacy</Text><Text style={styles.noteText}>Clients do not need a Supabase account. They use only a Bluezone token and secure device activation; broker and MT5 credentials are never requested.</Text></View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { flexGrow: 1, justifyContent: "center", padding: 22 },
  back: { color: "#2563EB", fontSize: 14, fontWeight: "900" },
  eyebrow: { color: "#2563EB", fontSize: 11, fontWeight: "900", letterSpacing: 1.2, marginTop: 28 },
  title: { color: "#0B1220", fontSize: 32, fontWeight: "900", marginTop: 5 },
  intro: { color: "#64748B", fontSize: 13, lineHeight: 19, marginTop: 7 },
  input: { backgroundColor: "#FFFFFF", borderColor: "#CBD5E1", borderRadius: 13, borderWidth: 1, color: "#0B1220", fontSize: 14, marginTop: 14, minHeight: 47, paddingHorizontal: 13 },
  primary: { alignItems: "center", backgroundColor: "#2563EB", borderRadius: 13, justifyContent: "center", marginTop: 16, minHeight: 48 },
  primaryText: { color: "#FFFFFF", fontSize: 13, fontWeight: "900" },
  note: { backgroundColor: "#EFF6FF", borderRadius: 16, marginTop: 18, padding: 14 },
  noteTitle: { color: "#1D4ED8", fontSize: 12, fontWeight: "900" },
  noteText: { color: "#475569", fontSize: 12, lineHeight: 17, marginTop: 4 },
  disabled: { opacity: 0.55 }, pressed: { opacity: 0.72 },
});
