import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";

export default function WelcomeScreen() {
  const router = useRouter();

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]}>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.eyebrow}>BLUEZONE TRADING NETWORK</Text>
        <Text style={styles.title}>Welcome</Text>
        <Text style={styles.intro}>Choose the correct access path. Clients use a Bluezone activation token. The owner alone signs in to issue and manage tokens.</Text>

        <View style={styles.clientCard}>
          <Text style={styles.cardLabel}>CLIENT ACCESS</Text>
          <Text style={styles.cardTitle}>Activate or switch a device token</Text>
          <Text style={styles.cardText}>Use this after installing Bluezone, receiving a token, or renewing a token. No client Supabase account is required.</Text>
          <Pressable onPress={() => router.push("/client-access" as never)} style={({ pressed }) => [styles.clientButton, pressed && styles.pressed]}>
            <Text style={styles.clientButtonText}>Client activation</Text>
          </Pressable>
        </View>

        <View style={styles.ownerCard}>
          <Text style={styles.ownerLabel}>OWNER ACCESS</Text>
          <Text style={styles.ownerTitle}>Issue and manage customer tokens</Text>
          <Text style={styles.ownerText}>This area is restricted to the authorised Bluezone owner. Clients cannot use it to obtain access.</Text>
          <Pressable onPress={() => router.push("/auth" as never)} style={({ pressed }) => [styles.ownerButton, pressed && styles.pressed]}>
            <Text style={styles.ownerButtonText}>Owner sign in</Text>
          </Pressable>
        </View>

        <View style={styles.note}>
          <Text style={styles.noteTitle}>Trading and data notice</Text>
          <Text style={styles.noteText}>Bluezone provides market research and paper-trading tools. It does not place broker orders, collect broker credentials, or guarantee outcomes.</Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { flexGrow: 1, justifyContent: "center", padding: 22 },
  eyebrow: { color: "#2563EB", fontSize: 11, fontWeight: "900", letterSpacing: 1.2 },
  title: { color: "#0B1220", fontSize: 36, fontWeight: "900", marginTop: 6 },
  intro: { color: "#64748B", fontSize: 14, lineHeight: 21, marginTop: 8 },
  clientCard: { backgroundColor: "#0B1220", borderRadius: 18, marginTop: 24, padding: 18 },
  ownerCard: { backgroundColor: "#FFFFFF", borderColor: "#CBD5E1", borderRadius: 18, borderWidth: 1, marginTop: 13, padding: 18 },
  cardLabel: { color: "#2563EB", fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  cardTitle: { color: "#FFFFFF", fontSize: 18, fontWeight: "900", marginTop: 6 },
  cardText: { color: "#CBD5E1", fontSize: 12, lineHeight: 18, marginTop: 6 },
  ownerLabel: { color: "#2563EB", fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  ownerTitle: { color: "#0B1220", fontSize: 18, fontWeight: "900", marginTop: 6 },
  ownerText: { color: "#475569", fontSize: 12, lineHeight: 18, marginTop: 6 },
  clientButton: { alignItems: "center", backgroundColor: "#2563EB", borderRadius: 12, justifyContent: "center", marginTop: 16, minHeight: 48 },
  clientButtonText: { color: "#FFFFFF", fontSize: 13, fontWeight: "900" },
  ownerButton: { alignItems: "center", borderColor: "#2563EB", borderRadius: 12, borderWidth: 1, justifyContent: "center", marginTop: 16, minHeight: 48 },
  ownerButtonText: { color: "#1D4ED8", fontSize: 13, fontWeight: "900" },
  note: { backgroundColor: "#EFF6FF", borderRadius: 16, marginTop: 18, padding: 14 },
  noteTitle: { color: "#1D4ED8", fontSize: 12, fontWeight: "900" },
  noteText: { color: "#475569", fontSize: 12, lineHeight: 18, marginTop: 4 },
  pressed: { opacity: 0.72 },
});
