import { useState } from "react";
import { Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { useRouter } from "expo-router";
import * as Clipboard from "expo-clipboard";

import { ScreenContainer } from "@/components/screen-container";
import { openSupport } from "@/lib/bluezone-workspace";
import { getDeviceId, saveActivationToken } from "@/lib/device-activation";
import { deviceAccessMessage, shouldStoreActivation } from "@/lib/device-access-policy";
import { requestDeviceLicense } from "@/lib/device-license-api";
import { activationClipboardNotice, normalizeActivationTokenInput } from "@/lib/activation-input";
import { withRequestTimeout } from "@/lib/owner-auth-feedback";

type Notice = { tone: "error" | "success"; title: string; message: string };

export default function LicenseScreen() {
  const router = useRouter();
  const [token, setToken] = useState("");
  const [checking, setChecking] = useState(false);
  const [pasting, setPasting] = useState(false);
  const [notice, setNotice] = useState<Notice | null>(null);

  const pasteToken = async () => {
    setPasting(true);
    try {
      const clipboardValue = await Clipboard.getStringAsync();
      const message = activationClipboardNotice(clipboardValue);
      if (message) {
        setNotice({ tone: "error", title: "Nothing to paste", message });
        return;
      }
      setToken(normalizeActivationTokenInput(clipboardValue));
      setNotice({ tone: "success", title: "Token pasted", message: "Review the token and tap Activate device." });
    } catch {
      setNotice({ tone: "error", title: "Paste unavailable", message: "Bluezone could not read the clipboard. Allow clipboard access or paste manually into the field." });
    } finally {
      setPasting(false);
    }
  };

  const verify = async () => {
    const candidate = normalizeActivationTokenInput(token);
    if (!candidate) {
      setNotice({ tone: "error", title: "Activation token required", message: "Paste or enter the Bluezone token you received from the owner." });
      return;
    }
    setChecking(true);
    setNotice(null);
    try {
      const deviceId = await withRequestTimeout(getDeviceId(), "Preparing this device");
      const result = await requestDeviceLicense("activate", candidate, deviceId);
      if (!shouldStoreActivation(result)) {
        setNotice({ tone: "error", title: "Activation not accepted", message: deviceAccessMessage(result) });
        return;
      }
      await withRequestTimeout(saveActivationToken(candidate), "Saving activation");
      setToken("");
      setNotice({ tone: "success", title: "Device activated", message: result.message || "Your device is active." });
    } catch (error) {
      setNotice({ tone: "error", title: "Activation unavailable", message: error instanceof Error ? error.message : "Activation could not be completed. Please try again." });
    } finally {
      setChecking(false);
    }
  };

  return <ScreenContainer edges={["top", "bottom", "left", "right"]}><ScrollView contentContainerStyle={styles.content}><Pressable onPress={() => router.replace("/client-access" as never)}><Text style={styles.back}>‹ Client access</Text></Pressable><Text style={styles.eyebrow}>BLUEZONE ACTIVATION</Text><Text style={styles.title}>Activate this device</Text><Text style={styles.intro}>Paste the token supplied by the owner, then activate this device. Clients do not need a Supabase account.</Text><TextInput value={token} editable={!checking} onChangeText={(value) => { setToken(value); setNotice(null); }} autoCapitalize="characters" placeholder="BZN-… activation token" placeholderTextColor="#94A3B8" style={styles.input} /><Pressable disabled={checking || pasting} onPress={pasteToken} style={({ pressed }) => [styles.paste, (checking || pasting) && styles.disabled, pressed && styles.pressed]}><Text style={styles.pasteText}>{pasting ? "Reading clipboard…" : "Paste token"}</Text></Pressable><Pressable disabled={checking || pasting} onPress={verify} style={({ pressed }) => [styles.primary, (checking || pasting) && styles.disabled, pressed && styles.pressed]}><Text style={styles.primaryText}>{checking ? "Checking…" : "Activate device"}</Text></Pressable>{notice ? <View accessibilityRole="alert" style={[styles.notice, notice.tone === "success" ? styles.noticeSuccess : styles.noticeError]}><Text style={styles.noticeTitle}>{notice.title}</Text><Text style={styles.noticeText}>{notice.message}</Text></View> : null}{notice?.tone === "success" && notice.title === "Device activated" ? <Pressable onPress={() => router.replace("/risk-disclaimer" as never)} style={({ pressed }) => [styles.continue, pressed && styles.pressed]}><Text style={styles.primaryText}>Continue to risk disclosure</Text></Pressable> : null}<View style={styles.divider}><View style={styles.line} /><Text style={styles.dividerText}>NEED A TOKEN?</Text><View style={styles.line} /></View><Pressable onPress={() => openSupport("license").catch(() => Alert.alert("Support link unavailable", "Contact Bluezone support for a renewal token."))} style={({ pressed }) => [styles.outline, pressed && styles.pressed]}><Text style={styles.outlineText}>Request or renew on WhatsApp</Text></Pressable><Pressable onPress={() => router.push("/welcome" as never)} style={({ pressed }) => [styles.owner, pressed && styles.pressed]}><Text style={styles.ownerText}>Return to Welcome</Text></Pressable><Text style={styles.footnote}>The app stores this device’s activation securely. Clients never receive Supabase, broker, MT5, payment, or administrator credentials.</Text></ScrollView></ScreenContainer>;
}

const styles = StyleSheet.create({ content: { flexGrow: 1, justifyContent: "center", padding: 22 }, back: { color: "#2563EB", fontSize: 14, fontWeight: "900" }, eyebrow: { color: "#2563EB", fontSize: 11, fontWeight: "900", letterSpacing: 1.2, marginTop: 28 }, title: { color: "#0B1220", fontSize: 32, fontWeight: "900", marginTop: 5 }, intro: { color: "#64748B", fontSize: 13, lineHeight: 19, marginTop: 8 }, input: { backgroundColor: "#FFFFFF", borderColor: "#CBD5E1", borderRadius: 13, borderWidth: 1, color: "#0B1220", fontSize: 14, marginTop: 18, minHeight: 48, paddingHorizontal: 13 }, paste: { alignItems: "center", borderColor: "#2563EB", borderRadius: 13, borderWidth: 1, justifyContent: "center", marginTop: 10, minHeight: 43 }, pasteText: { color: "#1D4ED8", fontSize: 12, fontWeight: "900" }, primary: { alignItems: "center", backgroundColor: "#0B1220", borderRadius: 13, justifyContent: "center", marginTop: 10, minHeight: 48 }, continue: { alignItems: "center", backgroundColor: "#2563EB", borderRadius: 13, justifyContent: "center", marginTop: 10, minHeight: 48 }, primaryText: { color: "#FFFFFF", fontSize: 13, fontWeight: "900" }, notice: { borderRadius: 12, borderWidth: 1, marginTop: 12, padding: 12 }, noticeError: { backgroundColor: "#FEF2F2", borderColor: "#FCA5A5" }, noticeSuccess: { backgroundColor: "#ECFDF5", borderColor: "#6EE7B7" }, noticeTitle: { color: "#0B1220", fontSize: 13, fontWeight: "900" }, noticeText: { color: "#475569", fontSize: 12, lineHeight: 17, marginTop: 3 }, divider: { alignItems: "center", flexDirection: "row", gap: 9, marginVertical: 18 }, line: { backgroundColor: "#E2E8F0", flex: 1, height: 1 }, dividerText: { color: "#94A3B8", fontSize: 10, fontWeight: "900" }, outline: { alignItems: "center", borderColor: "#0F9B8E", borderRadius: 13, borderWidth: 1, justifyContent: "center", minHeight: 48 }, outlineText: { color: "#0F766E", fontSize: 13, fontWeight: "900" }, owner: { alignItems: "center", justifyContent: "center", marginTop: 12, minHeight: 38 }, ownerText: { color: "#2563EB", fontSize: 11, fontWeight: "900" }, footnote: { color: "#94A3B8", fontSize: 11, lineHeight: 16, marginTop: 17, textAlign: "center" }, disabled: { opacity: 0.55 }, pressed: { opacity: 0.72 } });
