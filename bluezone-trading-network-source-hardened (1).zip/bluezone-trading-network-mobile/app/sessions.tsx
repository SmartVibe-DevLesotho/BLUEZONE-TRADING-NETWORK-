import { ScrollView, StyleSheet, Text, View } from "react-native";
import { WorkspaceScreen, workspaceStyles } from "@/components/bluezone/workspace-screen";
import { sessions } from "@/lib/bluezone-content";

export default function SessionsScreen() {
  return <WorkspaceScreen eyebrow="PRACTICE CONTEXT" title="Sessions"><ScrollView showsVerticalScrollIndicator={false}><View style={styles.notice}><Text style={styles.noticeTitle}>Session reference</Text><Text style={styles.noticeText}>Session descriptions are educational context and do not promise trading hours, liquidity, or a market result.</Text></View>{sessions.map(([name, description], index) => <View key={name} style={workspaceStyles.card}><Text style={workspaceStyles.label}>SESSION {index + 1}</Text><Text style={[workspaceStyles.cardTitle, styles.title]}>{name}</Text><Text style={workspaceStyles.copy}>{description}</Text></View>)}</ScrollView></WorkspaceScreen>;
}
const styles = StyleSheet.create({ notice: { backgroundColor: "#EFF6FF", borderColor: "#BFDBFE", borderRadius: 16, borderWidth: 1, marginBottom: 14, padding: 14 }, noticeTitle: { color: "#1D4ED8", fontSize: 13, fontWeight: "800" }, noticeText: { color: "#475569", fontSize: 12, lineHeight: 18, marginTop: 4 }, title: { marginTop: 5 } });
