import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { WorkspaceScreen, workspaceStyles } from "@/components/bluezone/workspace-screen";

const items = [
  ["Market universe", "Browse the supplied Forex, metals, crypto, index, and training-only catalog.", "/market-universe"],
  ["Strategies", "Review the supplied practice methodology references without trade recommendations.", "/strategies"],
  ["Sessions", "Use Asia, London, and New York as paper-trading learning context.", "/sessions"],
  ["Education", "Read foundational market and risk-management concepts.", "/education"],
  ["Cloud & broker status", "Review Supabase readiness and the no-execution broker boundary.", "/integration-status"],
] as const;

export default function ExploreScreen() {
  const router = useRouter();
  return <WorkspaceScreen eyebrow="BLUEZONE WORKSPACE" title="Explore"><ScrollView showsVerticalScrollIndicator={false}>{items.map(([title, copy, route]) => <Pressable key={route} onPress={() => router.push(route as never)} style={({ pressed }) => [workspaceStyles.card, styles.row, pressed && workspaceStyles.pressed]}><View style={styles.copy}><Text style={workspaceStyles.cardTitle}>{title}</Text><Text style={workspaceStyles.copy}>{copy}</Text></View><Text style={styles.chevron}>›</Text></Pressable>)}</ScrollView></WorkspaceScreen>;
}
const styles = StyleSheet.create({ row: { alignItems: "center", flexDirection: "row", minHeight: 85 }, copy: { flex: 1 }, chevron: { color: "#2563EB", fontSize: 28, fontWeight: "300", marginLeft: 12 } });
