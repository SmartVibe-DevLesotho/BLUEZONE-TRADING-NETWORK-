import { ScrollView, StyleSheet, Text, View } from "react-native";
import { WorkspaceScreen, workspaceStyles } from "@/components/bluezone/workspace-screen";
import { strategies } from "@/lib/bluezone-content";

export default function StrategiesScreen() {
  return <WorkspaceScreen eyebrow="PRACTICE REFERENCE" title="Strategies"><ScrollView showsVerticalScrollIndicator={false}><View style={styles.notice}><Text style={styles.noticeTitle}>Educational only</Text><Text style={styles.noticeText}>These source-provided strategy names describe study material. They are not signals, recommendations, or automated orders.</Text></View>{strategies.map(([name, description, color]) => <View key={name} style={workspaceStyles.card}><Text style={workspaceStyles.label}>{color.toUpperCase()} REFERENCE</Text><Text style={[workspaceStyles.cardTitle, styles.title]}>{name}</Text><Text style={workspaceStyles.copy}>{description}</Text></View>)}</ScrollView></WorkspaceScreen>;
}
const styles = StyleSheet.create({ notice: { backgroundColor: "#FFFBEB", borderColor: "#FDE68A", borderRadius: 16, borderWidth: 1, marginBottom: 14, padding: 14 }, noticeTitle: { color: "#92400E", fontSize: 13, fontWeight: "800" }, noticeText: { color: "#6B7280", fontSize: 12, lineHeight: 18, marginTop: 4 }, title: { marginTop: 5 } });
