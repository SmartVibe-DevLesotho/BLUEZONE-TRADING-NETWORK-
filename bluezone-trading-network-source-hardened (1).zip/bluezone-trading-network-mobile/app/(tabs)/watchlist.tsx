import { FlatList, StyleSheet, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { QuoteRow } from "@/components/bluezone/quote-row";
import { ScreenContainer } from "@/components/screen-container";
import { usePaperAccount } from "@/lib/paper-account-context";

export default function WatchlistScreen() {
  const router = useRouter();
  const { quotes, quoteFeed } = usePaperAccount();
  return <ScreenContainer><FlatList contentContainerStyle={styles.content} data={quotes} keyExtractor={(quote) => quote.symbol} renderItem={({ item }) => <QuoteRow quote={item} onPress={() => router.push({ pathname: "/instrument/[symbol]", params: { symbol: item.symbol } })} />} ListHeaderComponent={<View style={styles.header}><Text style={styles.eyebrow}>PAPER-TRADING WATCHLIST</Text><Text style={styles.title}>Watchlist</Text><Text style={styles.description}>{quoteFeed.status === "public" ? "Current public-provider quotes, refreshed by the Bluezone server. Public market data can be delayed." : "Public quotes are unavailable or incomplete, so affected rows retain the bundled training fallback."}</Text></View>} showsVerticalScrollIndicator={false} /></ScreenContainer>;
}
const styles = StyleSheet.create({ content: { padding: 20, paddingBottom: 24 }, header: { marginBottom: 18, marginTop: 8 }, eyebrow: { color: "#2563EB", fontSize: 11, fontWeight: "800", letterSpacing: 1.3 }, title: { color: "#0B1220", fontSize: 32, fontWeight: "800", letterSpacing: -1, marginTop: 5 }, description: { color: "#64748B", fontSize: 13, lineHeight: 19, marginTop: 8 } });
