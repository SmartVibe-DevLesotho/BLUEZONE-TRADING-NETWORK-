import { useEffect, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { DEVELOPER, openSupport } from "@/lib/bluezone-workspace";
import { getActivationToken } from "@/lib/device-activation";

export default function ProfileScreen() {
  const router = useRouter();
  const [hasActivation, setHasActivation] = useState(false);

  useEffect(() => {
    getActivationToken().then((token) => setHasActivation(Boolean(token))).catch(() => setHasActivation(false));
  }, []);

  return <ScreenContainer><ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <Text style={styles.eyebrow}>DEVICE PROFILE</Text>
    <Text style={styles.title}>Profile</Text>
    <View style={styles.profile}><View style={styles.avatar}><Text style={styles.avatarText}>B</Text></View><View><Text style={styles.user}>Bluezone client device</Text><Text style={styles.sub}>{hasActivation ? "Activation token stored securely" : "No client token stored"}</Text></View></View>
    <View style={styles.card}><Text style={styles.cardTitle}>Client activation</Text><Text style={styles.cardText}>Clients do not sign into Supabase. Use a Bluezone token supplied by the owner to activate or renew this device.</Text><Pressable onPress={() => router.push("/client-access" as never)} style={({ pressed }) => [styles.primary, pressed && styles.pressed]}><Text style={styles.primaryText}>Manage device token</Text></Pressable></View>
    <View style={styles.card}><Text style={styles.cardTitle}>Owner access</Text><Text style={styles.cardText}>Only the authorised owner can issue, renew, or revoke client tokens. The owner console verifies the account again on the server.</Text><Pressable onPress={() => router.push("/auth" as never)} style={({ pressed }) => [styles.outline, pressed && styles.pressed]}><Text style={styles.outlineText}>Owner sign in</Text></Pressable></View>
    <View style={styles.darkCard}><Text style={styles.darkLabel}>MT5 / ROBOT AUTOMATION</Text><Text style={styles.darkTitle}>Manual-only</Text><Text style={styles.darkText}>Bluezone does not collect or store MT5 login numbers, passwords, or server names. Users can review market research and decide independently whether to trade manually with their own broker; no broker action is initiated by this app.</Text></View>
    <View style={styles.card}><Text style={styles.cardTitle}>Developer credit</Text><Text style={styles.cardText}>{DEVELOPER.name}{"\n"}{DEVELOPER.email}</Text><Pressable onPress={() => openSupport("support").catch(() => undefined)} style={({ pressed }) => [styles.outline, pressed && styles.pressed]}><Text style={styles.outlineText}>Contact support</Text></Pressable></View>
  </ScrollView></ScreenContainer>;
}

const styles = StyleSheet.create({ content: { padding: 20, paddingBottom: 115 }, eyebrow: { color: "#2563EB", fontSize: 11, fontWeight: "800", letterSpacing: 1.2, marginTop: 8 }, title: { color: "#0B1220", fontSize: 32, fontWeight: "900", marginBottom: 16, marginTop: 5 }, profile: { alignItems: "center", flexDirection: "row", marginBottom: 15 }, avatar: { alignItems: "center", backgroundColor: "#2563EB", borderRadius: 24, height: 48, justifyContent: "center", marginRight: 11, width: 48 }, avatarText: { color: "#FFFFFF", fontSize: 20, fontWeight: "900" }, user: { color: "#0B1220", fontSize: 15, fontWeight: "900" }, sub: { color: "#64748B", fontSize: 11, marginTop: 3 }, card: { backgroundColor: "#FFFFFF", borderColor: "#E6EBF1", borderRadius: 18, borderWidth: 1, marginBottom: 12, padding: 16 }, cardTitle: { color: "#0B1220", fontSize: 15, fontWeight: "900" }, cardText: { color: "#64748B", fontSize: 12, lineHeight: 18, marginTop: 5 }, primary: { alignItems: "center", backgroundColor: "#2563EB", borderRadius: 12, justifyContent: "center", marginTop: 14, minHeight: 44 }, primaryText: { color: "#FFFFFF", fontSize: 12, fontWeight: "900" }, darkCard: { backgroundColor: "#0B1220", borderRadius: 18, marginBottom: 12, padding: 16 }, darkLabel: { color: "#94A3B8", fontSize: 10, fontWeight: "900", letterSpacing: 0.7 }, darkTitle: { color: "#FFFFFF", fontSize: 17, fontWeight: "900", marginTop: 5 }, darkText: { color: "#CBD5E1", fontSize: 12, lineHeight: 18, marginTop: 5 }, outline: { alignItems: "center", borderColor: "#BFDBFE", borderRadius: 12, borderWidth: 1, justifyContent: "center", marginTop: 14, minHeight: 42 }, outlineText: { color: "#2563EB", fontSize: 12, fontWeight: "900" }, pressed: { opacity: 0.7 } });
