import { Tabs } from "expo-router";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);
  return <Tabs screenOptions={{ headerShown: false, tabBarActiveTintColor: "#2563EB", tabBarInactiveTintColor: "#64748B", tabBarButton: HapticTab, tabBarStyle: { backgroundColor: "#FFFFFF", borderTopColor: "#E6EBF1", borderTopWidth: 1, height: 58 + bottomPadding, paddingBottom: bottomPadding, paddingTop: 8 }, tabBarLabelStyle: { fontSize: 9, fontWeight: "700" }, sceneStyle: { backgroundColor: colors.background } }}>
    <Tabs.Screen name="index" options={{ title: "Markets", tabBarIcon: ({ color }) => <IconSymbol size={23} name="chart.line.uptrend.xyaxis" color={color} /> }} />
    <Tabs.Screen name="chart" options={{ title: "Chart", tabBarIcon: ({ color }) => <IconSymbol size={23} name="chart.xyaxis.line" color={color} /> }} />
    <Tabs.Screen name="sessions" options={{ title: "Sessions", tabBarIcon: ({ color }) => <IconSymbol size={23} name="timer" color={color} /> }} />
    <Tabs.Screen name="autotrade" options={{ title: "AutoTrade", tabBarIcon: ({ color }) => <IconSymbol size={23} name="bolt.circle" color={color} /> }} />
    <Tabs.Screen name="brokers" options={{ title: "Brokers", tabBarIcon: ({ color }) => <IconSymbol size={23} name="building.2" color={color} /> }} />
    <Tabs.Screen name="more" options={{ title: "More", tabBarIcon: ({ color }) => <IconSymbol size={23} name="ellipsis.circle" color={color} /> }} />
    <Tabs.Screen name="profile" options={{ title: "Profile", tabBarIcon: ({ color }) => <IconSymbol size={23} name="person.crop.circle" color={color} /> }} />
    <Tabs.Screen name="watchlist" options={{ href: null }} />
    <Tabs.Screen name="portfolio" options={{ href: null }} />
    <Tabs.Screen name="activity" options={{ href: null }} />
    <Tabs.Screen name="settings" options={{ href: null }} />
  </Tabs>;
}
