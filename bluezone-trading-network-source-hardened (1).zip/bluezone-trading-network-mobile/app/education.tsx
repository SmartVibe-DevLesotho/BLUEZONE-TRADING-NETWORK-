import { ScrollView, StyleSheet, Text, View } from "react-native";
import { WorkspaceScreen, workspaceStyles } from "@/components/bluezone/workspace-screen";
import { educationModules } from "@/lib/bluezone-content";

export default function EducationScreen() {
  return <WorkspaceScreen eyebrow="BLUEZONE LEARNING" title="Education"><ScrollView showsVerticalScrollIndicator={false}>{educationModules.map(([category, title, description]) => <View key={title} style={workspaceStyles.card}><Text style={workspaceStyles.label}>{category.toUpperCase()}</Text><Text style={[workspaceStyles.cardTitle, styles.title]}>{title}</Text><Text style={workspaceStyles.copy}>{description}</Text></View>)}</ScrollView></WorkspaceScreen>;
}
const styles = StyleSheet.create({ title: { marginTop: 5 } });
