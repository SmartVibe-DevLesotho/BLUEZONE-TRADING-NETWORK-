import { useEffect, useState } from "react";
import { Alert, Pressable, ScrollView, Share, StyleSheet, Text, TextInput, View } from "react-native";
import { Stack, useRouter } from "expo-router";
import * as Clipboard from "expo-clipboard";

import { ScreenContainer } from "@/components/screen-container";
import { supabase } from "@/lib/supabase";
import { ownerAuthMessage, withOwnerAuthTimeout } from "@/lib/owner-auth-feedback";
import { signOutOwnerSession } from "@/lib/owner-session-policy";

type LicenseRow = {
  id: string;
  label: string | null;
  active: boolean;
  expires_at: string | null;
  max_activations: number;
  activation_count: number;
  issued_at: string;
  revoked_at: string | null;
};

export default function LicenseAdminScreen() {
  const router = useRouter();
  const [licenses, setLicenses] = useState<LicenseRow[]>([]);
  const [label, setLabel] = useState("");
  const [days, setDays] = useState("30");
  const [limit, setLimit] = useState("1");
  const [loading, setLoading] = useState(true);
  const [authorized, setAuthorized] = useState<boolean | null>(null);
  const [issuing, setIssuing] = useState(false);
  const [signingOut, setSigningOut] = useState(false);
  const [revokingId, setRevokingId] = useState<string | null>(null);
  const [confirmRevocationId, setConfirmRevocationId] = useState<string | null>(null);
  const [revokeResults, setRevokeResults] = useState<Record<string, string>>({});
  const [oneTimeToken, setOneTimeToken] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const load = async () => {
    if (!supabase) return;
    setLoading(true);
    const { data, error } = await supabase.functions.invoke("license-admin", { body: { action: "list" } });
    setLoading(false);
    if (error || !data?.ok) {
      const message = data?.message ?? "This console is only available to the configured Bluezone owner.";
      setAuthorized(false);
      setNotice(message);
      Alert.alert("Owner access required", message);
      return;
    }
    setAuthorized(true);
    setLicenses(data.licenses ?? []);
  };

  useEffect(() => {
    load().catch(() => undefined);
  }, []);

  const issue = async () => {
    if (!supabase) return;
    const durationDays = Number(days);
    const maxActivations = Number(limit);
    if (!Number.isInteger(durationDays) || !Number.isInteger(maxActivations)) {
      Alert.alert("Check token details", "Enter whole numbers for subscription days and device limit.");
      return;
    }
    setIssuing(true);
    try {
      const { data, error } = await withOwnerAuthTimeout(
        supabase.functions.invoke("license-admin", { body: { action: "issue", label, durationDays, maxActivations } }),
      );
      if (error || !data?.ok || !data.token) {
        Alert.alert("Token not issued", data?.message ?? ownerAuthMessage(error));
        return;
      }
      setOneTimeToken(data.token);
      setLabel("");
      load().catch(() => undefined);
    } catch (error) {
      Alert.alert("Token issue unavailable", ownerAuthMessage(error));
    } finally {
      setIssuing(false);
    }
  };

  const signOut = async () => {
    const client = supabase;
    if (!client) {
      router.replace("/license" as never);
      return;
    }
    setSigningOut(true);
    try {
      const target = await withOwnerAuthTimeout(signOutOwnerSession(() => client.auth.signOut()));
      router.replace(target as never);
    } catch (error) {
      Alert.alert("Owner sign-out unavailable", ownerAuthMessage(error));
    } finally {
      setSigningOut(false);
    }
  };

  const copyOneTimeToken = async () => {
    if (!oneTimeToken) return;
    try {
      await Clipboard.setStringAsync(oneTimeToken);
      Alert.alert("Token copied", "Paste it into your secure WhatsApp, SMS, or email message to the client.");
    } catch {
      Alert.alert("Copy unavailable", "Select the token text and copy it manually before closing this screen.");
    }
  };

  const shareOneTimeToken = async () => {
    if (!oneTimeToken) return;
    try {
      await Share.share({
        message: `Bluezone activation token: ${oneTimeToken}\n\nEnter this token in Bluezone on the client device. Keep it private.`,
        title: "Bluezone activation token",
      });
    } catch {
      Alert.alert("Share unavailable", "Use Copy token and send it through your preferred secure channel.");
    }
  };

  const revoke = async (licenseId: string) => {
    if (!supabase) return;
    setRevokingId(licenseId);
    setRevokeResults((current) => ({ ...current, [licenseId]: "Revoking token…" }));
    setNotice("Revoking token…");
    try {
      const { data, error } = await withOwnerAuthTimeout(
        supabase.functions.invoke("license-admin", { body: { action: "revoke", licenseId } }),
      );
      if (error || !data?.ok) {
        const message = data?.message ?? ownerAuthMessage(error);
        const result = `Revocation unavailable: ${message}`;
        setNotice(result);
        setRevokeResults((current) => ({ ...current, [licenseId]: result }));
        Alert.alert("Revocation unavailable", message);
        return;
      }
      const revokedAt = new Date().toISOString();
      setLicenses((current) => current.map((license) => license.id === licenseId ? { ...license, active: false, revoked_at: revokedAt } : license));
      const result = "Token revoked. Future activation checks will deny this device token.";
      setNotice(result);
      setRevokeResults((current) => ({ ...current, [licenseId]: result }));
      Alert.alert("Token revoked", "The token is disabled. A device using it will lose access at its next activation check.");
      setConfirmRevocationId(null);
      await load();
    } catch (error) {
      const message = ownerAuthMessage(error);
      const result = `Revocation unavailable: ${message}`;
      setNotice(result);
      setRevokeResults((current) => ({ ...current, [licenseId]: result }));
      Alert.alert("Revocation unavailable", message);
    } finally {
      setRevokingId(null);
    }
  };

  return (
    <ScreenContainer edges={["top", "bottom", "left", "right"]}>
      <Stack.Screen options={{ headerShown: true, title: "Activation tokens" }} />
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.eyebrow}>OWNER CONSOLE</Text>
        <Text style={styles.title}>Activation tokens</Text>
        <Text style={styles.intro}>Issue device tokens for clients. Bluezone stores only a secure hash, so copy or share the raw token immediately when it appears below.</Text>
        <Pressable disabled={signingOut} onPress={signOut} style={({ pressed }) => [styles.signOut, signingOut && styles.disabled, pressed && styles.pressed]}>
          <Text style={styles.signOutText}>{signingOut ? "Signing out…" : "Owner sign out — test client activation"}</Text>
        </Pressable>
        <Text style={styles.signOutHint}>This ends only the owner’s Supabase session. It does not delete a client device token.</Text>

        {notice ? <View style={styles.notice}><Text style={styles.noticeText}>{notice}</Text></View> : null}

        {authorized === false ? <View style={styles.deniedCard}>
          <Text style={styles.deniedTitle}>Owner access is restricted</Text>
          <Text style={styles.deniedText}>This signed-in account is not the authorised Bluezone owner. It cannot view, issue, renew, or revoke client tokens.</Text>
        </View> : <>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Issue a token</Text>
          <TextInput value={label} onChangeText={setLabel} placeholder="Customer label (optional)" placeholderTextColor="#94A3B8" style={styles.input} />
          <View style={styles.inline}>
            <TextInput value={days} onChangeText={setDays} keyboardType="number-pad" placeholder="Days" placeholderTextColor="#94A3B8" style={[styles.input, styles.half]} />
            <TextInput value={limit} onChangeText={setLimit} keyboardType="number-pad" placeholder="Device limit" placeholderTextColor="#94A3B8" style={[styles.input, styles.half]} />
          </View>
          <Pressable disabled={issuing} onPress={issue} style={({ pressed }) => [styles.primary, issuing && styles.disabled, pressed && styles.pressed]}>
            <Text style={styles.primaryText}>{issuing ? "Issuing…" : "Issue owner token"}</Text>
          </Pressable>
        </View>

        {oneTimeToken ? <View style={styles.tokenCard}>
          <Text style={styles.tokenLabel}>NEW TOKEN — COPY OR SHARE NOW</Text>
          <Text selectable style={styles.tokenValue}>{oneTimeToken}</Text>
          <Text style={styles.tokenNote}>This raw token is shown only in this session. It cannot be recovered from the issued list after you dismiss it.</Text>
          <View style={styles.tokenActions}>
            <Pressable onPress={copyOneTimeToken} style={({ pressed }) => [styles.copy, pressed && styles.pressed]}><Text style={styles.copyText}>Copy token</Text></Pressable>
            <Pressable onPress={shareOneTimeToken} style={({ pressed }) => [styles.share, pressed && styles.pressed]}><Text style={styles.shareText}>Share token</Text></Pressable>
          </View>
          <Pressable onPress={() => setOneTimeToken(null)} style={styles.dismiss}><Text style={styles.dismissText}>I copied it — hide token</Text></Pressable>
        </View> : null}

        <Text style={styles.section}>Issued tokens</Text>
        {loading ? <Text style={styles.muted}>Loading owner records…</Text> : licenses.length ? licenses.map((license) => {
          const confirming = confirmRevocationId === license.id;
          const revokeResult = revokeResults[license.id];
          return <View key={license.id} style={styles.license}>
            <View style={styles.licenseInfo}>
              <Text style={styles.licenseTitle}>{license.label || "Unlabelled subscription"}</Text>
              <Text style={styles.muted}>{license.active && !license.revoked_at ? "ACTIVE" : "REVOKED"} · {license.activation_count}/{license.max_activations} devices · expires {license.expires_at ? new Date(license.expires_at).toLocaleDateString() : "never"}</Text>
              {confirming ? <Text style={styles.confirmText}>Tap Confirm revoke to disable this token.</Text> : null}
              {revokeResult ? <Text style={styles.revokeResult}>{revokeResult}</Text> : null}
            </View>
            {license.active && !license.revoked_at ? <Pressable disabled={revokingId === license.id} onPress={() => confirming ? revoke(license.id) : setConfirmRevocationId(license.id)}>
              <Text style={[styles.revoke, confirming && styles.confirmRevoke, revokingId === license.id && styles.disabled]}>{revokingId === license.id ? "Revoking…" : confirming ? "Confirm revoke" : "Revoke"}</Text>
            </Pressable> : null}
          </View>;
        }) : <View style={styles.empty}><Text style={styles.cardTitle}>No tokens issued yet</Text><Text style={styles.muted}>Create the first token above after choosing its subscription duration.</Text></View>}

        <View style={styles.note}>
          <Text style={styles.noteTitle}>Security boundary</Text>
          <Text style={styles.noteText}>Raw tokens are not stored in Bluezone’s database, so old entries cannot be copied. Revoke an unused entry and issue a replacement; then copy or share the new token immediately.</Text>
        </View>
        </>}
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { padding: 20, paddingBottom: 36 },
  eyebrow: { color: "#2563EB", fontSize: 11, fontWeight: "900", letterSpacing: 1.1, marginTop: 5 },
  title: { color: "#0B1220", fontSize: 30, fontWeight: "900", marginTop: 4 },
  intro: { color: "#64748B", fontSize: 12, lineHeight: 18, marginTop: 7 },
  signOut: { alignItems: "center", borderColor: "#2563EB", borderRadius: 11, borderWidth: 1, justifyContent: "center", marginTop: 12, minHeight: 43 },
  signOutText: { color: "#1D4ED8", fontSize: 12, fontWeight: "900" },
  signOutHint: { color: "#64748B", fontSize: 10, lineHeight: 14, marginTop: 5, textAlign: "center" },
  notice: { backgroundColor: "#EFF6FF", borderColor: "#93C5FD", borderRadius: 12, borderWidth: 1, marginTop: 12, padding: 11 },
  noticeText: { color: "#1D4ED8", fontSize: 11, fontWeight: "800", lineHeight: 16 },
  deniedCard: { backgroundColor: "#FEF2F2", borderColor: "#FCA5A5", borderRadius: 16, borderWidth: 1, marginTop: 17, padding: 15 },
  deniedTitle: { color: "#B42318", fontSize: 14, fontWeight: "900" },
  deniedText: { color: "#7F1D1D", fontSize: 12, lineHeight: 18, marginTop: 5 },
  card: { backgroundColor: "#FFFFFF", borderColor: "#E6EBF1", borderRadius: 16, borderWidth: 1, marginTop: 17, padding: 15 },
  cardTitle: { color: "#0B1220", fontSize: 14, fontWeight: "900" },
  input: { backgroundColor: "#F8FAFC", borderColor: "#CBD5E1", borderRadius: 11, borderWidth: 1, color: "#0B1220", fontSize: 12, marginTop: 10, minHeight: 43, paddingHorizontal: 11 },
  inline: { flexDirection: "row", gap: 9 }, half: { flex: 1 },
  primary: { alignItems: "center", backgroundColor: "#2563EB", borderRadius: 11, justifyContent: "center", marginTop: 12, minHeight: 44 },
  primaryText: { color: "#FFFFFF", fontSize: 12, fontWeight: "900" },
  tokenCard: { backgroundColor: "#ECFDF5", borderColor: "#6EE7B7", borderRadius: 16, borderWidth: 1, marginTop: 13, padding: 14 },
  tokenLabel: { color: "#047857", fontSize: 10, fontWeight: "900", letterSpacing: 0.7 },
  tokenValue: { color: "#0B1220", fontFamily: "monospace", fontSize: 12, fontWeight: "900", lineHeight: 19, marginTop: 8 },
  tokenNote: { color: "#475569", fontSize: 11, lineHeight: 16, marginTop: 8 },
  tokenActions: { flexDirection: "row", gap: 8, marginTop: 12 },
  copy: { alignItems: "center", backgroundColor: "#0F766E", borderRadius: 10, flex: 1, justifyContent: "center", minHeight: 40 },
  copyText: { color: "#FFFFFF", fontSize: 12, fontWeight: "900" },
  share: { alignItems: "center", borderColor: "#0F766E", borderRadius: 10, borderWidth: 1, flex: 1, justifyContent: "center", minHeight: 40 },
  shareText: { color: "#0F766E", fontSize: 12, fontWeight: "900" },
  dismiss: { alignItems: "center", justifyContent: "center", marginTop: 10, minHeight: 30 },
  dismissText: { color: "#475569", fontSize: 11, fontWeight: "900" },
  section: { color: "#0B1220", fontSize: 17, fontWeight: "900", marginBottom: 9, marginTop: 21 },
  license: { alignItems: "center", backgroundColor: "#FFFFFF", borderColor: "#E6EBF1", borderRadius: 14, borderWidth: 1, flexDirection: "row", justifyContent: "space-between", marginBottom: 8, padding: 13 },
  licenseInfo: { flex: 1, paddingRight: 9 }, licenseTitle: { color: "#0B1220", fontSize: 13, fontWeight: "900" },
  muted: { color: "#64748B", fontSize: 11, lineHeight: 16, marginTop: 3 },
  revoke: { color: "#E5484D", fontSize: 11, fontWeight: "900" },
  confirmRevoke: { color: "#B42318", textDecorationLine: "underline" },
  confirmText: { color: "#B42318", fontSize: 10, fontWeight: "700", marginTop: 5 },
  revokeResult: { color: "#1D4ED8", fontSize: 10, fontWeight: "800", lineHeight: 14, marginTop: 5 },
  empty: { backgroundColor: "#F8FAFC", borderRadius: 14, padding: 14 },
  note: { backgroundColor: "#EFF6FF", borderRadius: 14, marginTop: 16, padding: 14 },
  noteTitle: { color: "#1D4ED8", fontSize: 11, fontWeight: "900" },
  noteText: { color: "#475569", fontSize: 11, lineHeight: 16, marginTop: 4 },
  disabled: { opacity: 0.55 }, pressed: { opacity: 0.72 },
});
