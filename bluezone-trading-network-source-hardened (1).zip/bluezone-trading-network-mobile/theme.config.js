/** @type {const} */
const themeColors = {
  primary: { light: "#2563EB", dark: "#2563EB" },
  background: { light: "#F8FAFC", dark: "#F8FAFC" },
  surface: { light: "#FFFFFF", dark: "#FFFFFF" },
  foreground: { light: "#0B1220", dark: "#0B1220" },
  muted: { light: "#64748B", dark: "#64748B" },
  border: { light: "#E6EBF1", dark: "#E6EBF1" },
  success: { light: "#0F9B8E", dark: "#0F9B8E" },
  warning: { light: "#E6A23C", dark: "#E6A23C" },
  error: { light: "#E5484D", dark: "#E5484D" },
};

module.exports = { themeColors };
