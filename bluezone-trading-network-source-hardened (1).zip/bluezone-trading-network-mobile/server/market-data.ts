import type { Quote } from "../lib/bluezone-data";

const CACHE_TTL_MS = 60_000;
const REQUEST_TIMEOUT_MS = 8_000;

export type PublicMarketQuote = Quote & { providerSymbol: string; provider: "Yahoo Finance public quote"; origin: "public"; asOf: string };
export type PublicMarketFeed = { provider: "Yahoo Finance public quote"; status: "public" | "partial" | "unavailable"; fetchedAt: string; cacheTtlSeconds: number; quotes: PublicMarketQuote[]; unavailableSymbols: string[] };
type InstrumentConfig = Pick<Quote, "symbol" | "name" | "assetClass"> & { providerSymbol: string };

const fxPairs = ["EURUSD", "GBPUSD", "USDJPY", "USDCHF", "AUDUSD", "USDCAD", "NZDUSD", "EURGBP", "EURJPY", "GBPJPY", "EURCHF", "AUDJPY", "EURAUD", "GBPAUD", "GBPCAD", "EURCAD", "NZDJPY", "CADJPY", "CHFJPY", "AUDCAD", "AUDNZD", "AUDCHF", "GBPNZD", "EURNZD", "GBPCHF", "CADCHF", "NZDCAD", "NZDCHF"];
const fxProviderOverride: Record<string, string> = { USDJPY: "JPY=X", USDCHF: "CHF=X", USDCAD: "CAD=X" };
export const PUBLIC_INSTRUMENTS: InstrumentConfig[] = [
  ...fxPairs.map((symbol) => ({ symbol, name: symbol, assetClass: "FX" as const, providerSymbol: fxProviderOverride[symbol] ?? `${symbol}=X` })),
  { symbol: "XAUUSD", name: "Gold", assetClass: "Metal", providerSymbol: "GC=F" },
  { symbol: "XAGUSD", name: "Silver", assetClass: "Metal", providerSymbol: "SI=F" },
  { symbol: "XPTUSD", name: "Platinum", assetClass: "Metal", providerSymbol: "PL=F" },
  { symbol: "BTCUSD", name: "Bitcoin", assetClass: "Crypto", providerSymbol: "BTC-USD" },
  { symbol: "ETHUSD", name: "Ethereum", assetClass: "Crypto", providerSymbol: "ETH-USD" },
  { symbol: "LTCUSD", name: "Litecoin", assetClass: "Crypto", providerSymbol: "LTC-USD" },
  { symbol: "XRPUSD", name: "XRP", assetClass: "Crypto", providerSymbol: "XRP-USD" },
  { symbol: "LINKUSD", name: "Chainlink", assetClass: "Crypto", providerSymbol: "LINK-USD" },
  { symbol: "BNBUSD", name: "BNB", assetClass: "Crypto", providerSymbol: "BNB-USD" },
  { symbol: "SOLUSD", name: "Solana", assetClass: "Crypto", providerSymbol: "SOL-USD" },
  { symbol: "US30", name: "Dow Jones", assetClass: "Index", providerSymbol: "^DJI" },
  { symbol: "US500", name: "S&P 500", assetClass: "Index", providerSymbol: "^GSPC" },
  { symbol: "US100", name: "Nasdaq 100", assetClass: "Index", providerSymbol: "^NDX" },
  { symbol: "UK100", name: "FTSE 100", assetClass: "Index", providerSymbol: "^FTSE" },
  { symbol: "GER40", name: "Germany 40", assetClass: "Index", providerSymbol: "^GDAXI" },
  { symbol: "JPN225", name: "Japan 225", assetClass: "Index", providerSymbol: "^N225" },
  { symbol: "AUS200", name: "Australia 200", assetClass: "Index", providerSymbol: "^AXJO" },
];

type CachedFeed = { expiresAt: number; feed: PublicMarketFeed };
let cache: CachedFeed | null = null;
type YahooChartResponse = { chart?: { result?: Array<{ meta?: { regularMarketPrice?: number; regularMarketChangePercent?: number; regularMarketTime?: number; chartPreviousClose?: number; previousClose?: number }; indicators?: { quote?: Array<{ close?: Array<number | null> }> } }> | null } };
function finiteNumber(value: unknown): number | null { return typeof value === "number" && Number.isFinite(value) ? value : null; }

export function normalizeYahooChart(instrument: InstrumentConfig, payload: YahooChartResponse, fetchedAt = new Date().toISOString()): PublicMarketQuote | null {
  const chart = payload.chart?.result?.[0]; const meta = chart?.meta; if (!meta) return null;
  const latestClose = chart?.indicators?.quote?.[0]?.close?.filter((value): value is number => finiteNumber(value) !== null).at(-1) ?? null;
  const price = finiteNumber(meta.regularMarketPrice) ?? latestClose; if (price === null || price <= 0) return null;
  const reportedChange = finiteNumber(meta.regularMarketChangePercent); const previousClose = finiteNumber(meta.chartPreviousClose) ?? finiteNumber(meta.previousClose);
  return { ...instrument, price, changePercent: reportedChange ?? (previousClose && previousClose > 0 ? ((price - previousClose) / previousClose) * 100 : 0), provider: "Yahoo Finance public quote", origin: "public", asOf: finiteNumber(meta.regularMarketTime) ? new Date(meta.regularMarketTime! * 1000).toISOString() : fetchedAt };
}

async function fetchInstrument(instrument: InstrumentConfig, fetchedAt: string): Promise<PublicMarketQuote | null> {
  const response = await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(instrument.providerSymbol)}?range=1d&interval=1m`, { headers: { Accept: "application/json", "User-Agent": "Mozilla/5.0 BluezoneMarketData/1.0" }, signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS) });
  if (!response.ok) return null;
  return normalizeYahooChart(instrument, (await response.json()) as YahooChartResponse, fetchedAt);
}

async function fetchInBatches(configs: InstrumentConfig[], fetchedAt: string) {
  const batchSize = 8; const quotes: PublicMarketQuote[] = [];
  for (let index = 0; index < configs.length; index += batchSize) {
    const settled = await Promise.allSettled(configs.slice(index, index + batchSize).map((instrument) => fetchInstrument(instrument, fetchedAt)));
    quotes.push(...settled.flatMap((result) => result.status === "fulfilled" && result.value ? [result.value] : []));
  }
  return quotes;
}

export async function getPublicMarketFeed(now = Date.now()): Promise<PublicMarketFeed> {
  if (cache && cache.expiresAt > now) return cache.feed;
  const fetchedAt = new Date(now).toISOString(); const quotes = await fetchInBatches(PUBLIC_INSTRUMENTS, fetchedAt); const available = new Set(quotes.map((quote) => quote.symbol));
  const unavailableSymbols = PUBLIC_INSTRUMENTS.filter((instrument) => !available.has(instrument.symbol)).map((instrument) => instrument.symbol);
  const status: PublicMarketFeed["status"] = quotes.length === PUBLIC_INSTRUMENTS.length ? "public" : quotes.length > 0 ? "partial" : "unavailable";
  const feed: PublicMarketFeed = { provider: "Yahoo Finance public quote", status, fetchedAt, cacheTtlSeconds: CACHE_TTL_MS / 1000, quotes, unavailableSymbols }; cache = { feed, expiresAt: now + CACHE_TTL_MS }; return feed;
}
