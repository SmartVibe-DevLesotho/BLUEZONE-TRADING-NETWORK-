import { PUBLIC_INSTRUMENTS } from "./market-data";
import { evaluateLiveSignal, type LiveSignalDirection, type LiveSignalStrength } from "../lib/live-signal-engine";

const CACHE_TTL_MS = 60_000;
const REQUEST_TIMEOUT_MS = 8_000;
const SIGNAL_SYMBOLS = ["XAUUSD", "EURUSD", "GBPUSD", "USDJPY", "BTCUSD", "ETHUSD", "US30", "US500"];

export type MarketSignal = { symbol: string; name: string; price: number; asOf: string; direction: LiveSignalDirection; strength: LiveSignalStrength; alignmentScore: number; shortAverage: number | null; longAverage: number | null; momentumPercent: number | null; rsi14: number | null; invalidationReference: number | null; freshness: "fresh" | "stale"; inputs: string[]; rationale: string[]; disclaimer: string };
export type MarketSignalFeed = { provider: "Yahoo Finance public chart"; status: "public" | "partial" | "unavailable"; fetchedAt: string; cacheTtlSeconds: number; signals: MarketSignal[]; unavailableSymbols: string[] };
type ChartPayload = { chart?: { result?: Array<{ meta?: { regularMarketPrice?: number; regularMarketTime?: number }; timestamp?: number[]; indicators?: { quote?: Array<{ close?: Array<number | null> }> } }> | null } };
type Cached = { expiresAt: number; feed: MarketSignalFeed };
let cache: Cached | null = null;

function finite(value: unknown): value is number { return typeof value === "number" && Number.isFinite(value); }

export function computeMarketSignal(input: { symbol: string; name: string; closes: number[]; asOf: string; now?: number }): MarketSignal {
  const closes = input.closes.filter(finite); const price = closes.at(-1) ?? 0; const assessment = evaluateLiveSignal({ closes, asOf: input.asOf, now: input.now });
  return { symbol: input.symbol, name: input.name, price, asOf: input.asOf, ...assessment, disclaimer: "This is live, explainable market research from public history. It is not personalised financial advice, a guaranteed outcome, or an instruction to trade." };
}

async function fetchSignal(symbol: string, fetchedAt: string): Promise<MarketSignal | null> {
  const instrument = PUBLIC_INSTRUMENTS.find((candidate) => candidate.symbol === symbol); if (!instrument) return null;
  const response = await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(instrument.providerSymbol)}?range=1d&interval=1m`, { headers: { Accept: "application/json", "User-Agent": "Mozilla/5.0 BluezoneMarketData/1.0" }, signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS) });
  if (!response.ok) return null;
  const chart = ((await response.json()) as ChartPayload).chart?.result?.[0]; const closes = chart?.indicators?.quote?.[0]?.close?.filter(finite) ?? []; const price = chart?.meta?.regularMarketPrice ?? closes.at(-1); const asOf = chart?.meta?.regularMarketTime ? new Date(chart.meta.regularMarketTime * 1000).toISOString() : fetchedAt;
  if (!price || price <= 0) return null;
  const signal = computeMarketSignal({ symbol: instrument.symbol, name: instrument.name, closes, asOf });
  return signal.direction === "UNAVAILABLE" ? null : { ...signal, price };
}

export async function getMarketSignalFeed(now = Date.now()): Promise<MarketSignalFeed> {
  if (cache && cache.expiresAt > now) return cache.feed;
  const fetchedAt = new Date(now).toISOString(); const settled = await Promise.allSettled(SIGNAL_SYMBOLS.map((symbol) => fetchSignal(symbol, fetchedAt))); const signals = settled.flatMap((result) => result.status === "fulfilled" && result.value ? [result.value] : []); const available = new Set(signals.map((signal) => signal.symbol)); const unavailableSymbols = SIGNAL_SYMBOLS.filter((symbol) => !available.has(symbol)); const status: MarketSignalFeed["status"] = signals.length === SIGNAL_SYMBOLS.length ? "public" : signals.length ? "partial" : "unavailable"; const feed = { provider: "Yahoo Finance public chart" as const, status, fetchedAt, cacheTtlSeconds: CACHE_TTL_MS / 1000, signals, unavailableSymbols }; cache = { feed, expiresAt: now + CACHE_TTL_MS }; return feed;
}
